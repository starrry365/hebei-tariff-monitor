# -*- coding: utf-8 -*-
"""河北移动「资费专区」(nrapigate/nrtariff) 每日抓取 + 差异对比

适配云端 CI（GitHub Actions）与本地两种环境：
  - 路径全部相对脚本自身，不写死盘符
  - `--ssl-no-revoke` 仅 Windows Schannel 支持，Linux curl 会直接报 unknown option -> 按平台注入
  - 快照 gzip 压缩 + 只保留最近 KEEP 份，避免仓库体积失控
  - 查询页重建到 docs/index.html（不入 git），并 gzip 归档到 page/index.html.gz（入库）
    · 页面显示「数据基线日期」而非抓取时刻，数据没变则内容逐字节一致 -> 跳过归档
  - 数据量守卫：本次条目数 < 上次 60% 视为抓取异常 -> 不写快照、不出下线报告
  - 有变更时把摘要写进 GITHUB_STEP_SUMMARY（云端页面直接可读）

接口特性（2026-09-20 实测）：无需 APP / token / 签名，明文请求体 + curl 直取，
响应体 `{"body":"<密文>"}` 用网关密钥 AES-256-CBC 本地解密（见 mz_crypto.py）。
密钥不写在代码里：取环境变量 NRAPIGATE_KEY / NRAPIGATE_IV，或同目录 .nrapigate_key
文件（已 gitignore）；两边都没有直接抛错，绝不回退到硬编码值。

用法:
    python tariff_monitor.py              # 抓取 + 对比 + 报告 + HTML
    python tariff_monitor.py --no-html    # 只抓取与对比，不重建页面
    python tariff_monitor.py --render-only  # 不联网：用现有页面数据套当前模板重渲染
退出码: 0=正常  2=数据量骤降  3=网络全失败
"""
import datetime
import gzip
import io
import json
import os
import random
import re
import ssl
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
try:
    import mz_crypto  # noqa: E402
    _MZ_ERR = None
except Exception as _e:  # noqa: E402
    # 加解密依赖（pycryptodome）只有真正抓取时才用得到。
    # 本地裸环境（如系统 Python 没装 pycryptodome）也必须能跑 --render-only，
    # 否则「改了模板想看一眼」就被一个跟本次任务无关的依赖卡住。
    mz_crypto = None
    _MZ_ERR = _e

# ── 护栏与推送：都用 try 单独包，缺一个不影响另一个，也不影响抓取 ────────────
# ★ 为什么允许「导入失败还继续跑」：这两个模块都不是采集链路的必需件 ——
#   护栏是给数字上保险、推送是通知。为了它们让整轮巡检起不来，是本末倒置。
#   但**必须把它吼出来**：静默降级成「没有护栏」比没有护栏更糟（见变更报告里
#   那句「本题不允许静默降级」的同源原则）。
try:
    import change_guard as G  # noqa: E402
    _G_ERR = None
except Exception as _e:  # noqa: E402
    G, _G_ERR = None, _e
try:
    import notify as NOTIFY  # noqa: E402
    _N_ERR = None
except Exception as _e:  # noqa: E402
    NOTIFY, _N_ERR = None, _e
# ⑥ 采样噪声护栏（2026-10-04 接线）：change_guard 管「总数掉没掉」，
#    noise_guard 管「总数没掉但整批换人」—— 两个判据互补，缺一不可。
#    它的 docstring 从落库第一天就写着「要接入巡检」，此前只有 CI 的只读
#    体检在调它 —— 等于护栏造好了没装到门上（recheck-20261004 #2）。
#    同样允许导入失败继续跑（不是采集必需件），但 _NG_ERR 会吼出来。
try:
    import noise_guard as NG  # noqa: E402
    _NG_ERR = None
except Exception as _e:  # noqa: E402
    NG, _NG_ERR = None, _e

SNAP = os.path.join(BASE, "snapshots")
CHG = os.path.join(BASE, "changes")
DOCS = os.path.join(BASE, "docs")
HTML_DST = os.path.join(DOCS, "index.html")
STATE_FILE = os.path.join(BASE, "state.json")
# 页面归档：查询页没有公网入口，本机靠这个文件「不跑抓取就能看」
PAGE_DIR = os.path.join(BASE, "page")
PAGE_GZ = os.path.join(PAGE_DIR, "index.html.gz")
KEEP_SNAPSHOTS = 60          # 只保留最近 60 份快照（gzip 后约 0.53MB/份，工作区稳定在 ~32MB）
# 数据量骤降阈值与「连续多少轮才认账」都由 change_guard 统一定义 ——
# 这里只做一次转发，避免两个模块各写一份阈值（改一处漏一处的下场见 net_round 注释）。
DEGRADE_RATIO = getattr(G, "DEGRADE_RATIO", 0.6) if G else 0.6
DEGRADE_ACCEPT_ROUNDS = getattr(G, "DEGRADE_ACCEPT_ROUNDS", 3) if G else 3
# 降级计数必须**跨轮次持久化**（否则"连续 3 轮"退化成"每轮都算第一轮"）。
# 它入库，CI 每轮提交 —— 与 history.json 同理。
DEGRADE_STATE = os.path.join(BASE, "degrade_state.json")

ROOT = "https://h.app.coc.10086.cn/website/nrapigate/"
REF = ("https://h.app.coc.10086.cn/cmcc-app/uni-pages/tariffZonePers.html"
       "?pageId=1834149966764851200&channelId=P00000132579&yx=1390478183")
UA = ("Mozilla/5.0 (Linux; Android 16; 23113RKC6C Build/BP2A.250605.031.A3; wv) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/151.0.7922.199 "
      "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT")

# ── UA 指纹池（2026-10-06，参考同类项目实测）─────────────────────────────
# 源站网关按「IP + UA 指纹」**隔离**限流配额：同一 UA 的总配额有限，耗尽后
# **不报错而是返回确定性子集** —— 表现为整批假下架/假新增，正是假变化的上游
# 源头（我们的 noise_guard 在下游拦它，这里从源头少触发）。
# 对策：每个分类组合分配一个独立 UA = 独立配额池，互不挤占。
# 构造方式：保持移动 App WebView 指纹自洽 —— ``leadeon/CMCCIT`` 后缀与
# ``x-requested-with``（App 包名）头**都不动**，只轮换设备型号 / Android 版本 /
# Chrome 版本。换成纯 Chrome UA 反而和 App 伪装头对不上，画蛇添足。
# 分配是**确定性**的（按组合序号取模）：同一分类每轮都拿到同一个 UA，
# 配额池身份稳定 —— 若换成随机轮换，同一分类每轮换 UA，配额池身份就散了。
UA_POOL = (
    UA,
    "Mozilla/5.0 (Linux; Android 15; 24129PN5CC Build/AP4A.250105.002; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/150.0.7050.72 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 15; SM-S9310 Build/AP3A.240905.015; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7034.85 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 14; SM-S9110 Build/UP1A.231005.007; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.86 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 14; V2312A Build/UP1A.231005.007; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 14; PGT-AN10 Build/UP1A.231005.007; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/126.0.6478.122 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 13; ELE-AL00 Build/HUAWEIELE-AL00; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.43 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 13; 2201123C Build/TKQ1.220829.002; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/119.0.6045.66 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 13; V2141A Build/RP1A.200720.012; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.136 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 12; 21091116AC Build/SP1A.210812.016; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 12; M2012K11AC Build/RKQ1.211001.001; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/107.0.5304.141 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
    "Mozilla/5.0 (Linux; Android 11; PDEM-AN00 Build/HUAWEIPDEM-AN00; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 "
    "Mobile Safari/537.36 leadeon/12.5.4/CMCCIT",
)
PROV = "311"   # 河北
ZFLX = {"1": "套餐", "2": "加装包", "3": "营销活动", "4": "港澳台/国际资费",
        "5": "标准资费", "6": "国际及港澳台标准资费", "7": "其他"}

# ── 地域归属（三级口径：邢台 → 河北 → 全国）────────────────────────────
# 需求：只要「邢台 + 河北 + 全国」的资费；与河北无关的（其他省份专属）丢弃。
# 四网的地域字段差异极大，**逐网判** —— 不存在一套通用规则：
#   移动：applicableArea / city / province **三个**字段都可能带地域。取值形态有
#         2 字母省码（HE）、全国标记（000）、4 位地市码、多省 CSV、`!XX` 排除式
#   联通：条目里没有地域字段，但**采集侧**有 —— 12 城并集采集时逐条记了城市归属
#         （`_cityNames` / `_allCity`，见 probes/he_unicom_tariff.collect）
#   电信：applicableArea（HE / 地市码 CSV）+ applicableAreaLabel
#   广电：`_areaNames` 只有「全国 / 河北省」两档（上游无地市粒度）
#
# ★ 判定规则已用**已归档快照离线验证**（scope_proto 探针）：移动 3887 条无一落入
#   「无关」桶 → xz 104 / hb 2334 / cn 1449，合计 3887。电信 884 条同样零漏判。
#   验证这一步不能省：分类器写错了不会报错，只会**静默少一批条目**，
#   而页面上「少了些什么」这件事没有任何提示。
XINGTAI_CODE = "3190"        # 已实锤：条目名「邢台爱家光网服务预存活动-冀享专属」
# 河北 12 个地市码 → 中文名（**移动/电信**的 applicableArea 用这套 4 位码；
# 联通的地市码是另一套 3 位码，在 probes/he_unicom_tariff.CITY_CODES 里，
# 已在采集侧换成同一批中文名 —— 页面与对账脚本只看得到名字）。
# ★ 地市码是**条目级**信息：一条资费可覆盖多个市（CSV），也可能一个都不限（全省通用）。
# ★ 三条网有条目级地市信息（2026-09-24 更正）：
#     移动（4 位码，实测命中 1974 次）+ 文案兜底、电信（4 位码 CSV，265 次）、
#     联通（12 城并集采集，139/8042 条没有覆盖全部城市）。
#   🔴 广电是唯一真的没有的（区域码表只有省级）。
#   🔴🔴 这里曾把联通也归到「没有」那一档，依据是「采集侧只采了邢台一城 + 条目零地域
#     字段」—— 那是**抽样假阴性**：单城采集当然看不到城市差异（详见
#     docs/联通河北资费-地市维度纠错-20260924.md）。
HB_CITY = {"3100": "邯郸", "3110": "石家庄", "3120": "保定",
           "3121": "雄安新区", "3130": "张家口", "3140": "承德",
           "3150": "唐山", "3160": "廊坊", "3170": "沧州", "3180": "衡水",
           "3190": "邢台", "3350": "秦皇岛"}
HB_CITY_CODES = frozenset(HB_CITY)
# 🔴🔴 `3121` **不是**「省直辖（定州/辛集）」（2026-09-24 更正）。
#   判据 = 把 `applicableArea == "3121"`（该码**单独**出现）的条目全列出来：
#     雄安新区咪咕融合权益5次包 / 10次包 / 1次包 · 雄安9元返费优惠（12个月）
#     雄安公交出行权益包 · 雄安新区咪咕咖啡体验包（12Y） · 雄安金牌服务包A（12个月）
#     · 40G通用流量包（24个月，雄安专属）
#   8 条里 7 条名字直接写着「雄安」；而其余 11 个码单独出现时，名字各自写着自己的城市名
#   （3100 全部是「邯郸…」、3150 全部是「唐山…」）—— 只有 3121 对不上。
#   代号规律也自洽：雄安原属保定，3120 保定 ⇒ 3121 雄安。
#   后果（移动 + 电信**同时**受影响，两网共用这张表）：
#     · 「雄安新区」档拿不到那 8 条专属资费 —— 页面里它与「仅全省通用」数字完全一样，
#       看起来像「雄安根本没有资费」；
#     · 「省直辖（定州/辛集）」档装的是雄安的资费 + 一批全省资费，名不副实。
#   ⚠️ 上游**没有**给「定州 / 辛集」独立的地市码（逐码单独出现的条目里一个都没有），
#      它们的数据并入保定 / 石家庄 —— 所以 `CITY_ORDER` 里不再保留这个虚构档位。
#   判据脚本：`probes/probe_city_code_semantics.py`（人眼判据：码名必须能在条目名里看到）。

# ★★ 地市的**统一命名空间** —— 行数据（`cty`）、对账脚本、CI 断言都用它。
#   刻意用**中文名**而不是任何一套码：
#     移动/电信是 4 位码（3190=邢台）、联通是 3 位码（185=邢台）。两套码并存时，
#     拿到一个 `cty` 值得先问「这是哪张表的」—— 而值本身长得也像（纯数字），
#     判错的结果是「某个市的归属算错」，不报错、看着像「这个市本来就没资费」。
#   统一成名字后只有一套。
#   ⚠️ 2026-10-03 起这份清单**不再注入页面**（地市筛选整块下线，见 template.html
#      的 SC_LB 注释）—— 它的作用域现在只剩「构建期算 cty + 数据对账 + CI 断言」。
#      自带副本搞漂的下场见 audit_data.check_sync 的历史注释（改了一边忘了另一边）。
CITY_ORDER = ("石家庄", "唐山", "秦皇岛", "邯郸", "邢台", "保定",
              "张家口", "承德", "沧州", "廊坊", "衡水")
# 🔴 「省直辖（定州/辛集）」**已从本表移除**（2026-09-24）：上游三网都没有给它俩独立的
#   地市码 —— 移动/电信的 4 位码表里 3121 实测是「雄安新区」（见 HB_CITY 注释），
#   联通 cityList 的 12 个里也没有。留着一个**永远取不到数据**的档位，用户点进去
#   拿到的是「不限地市」那一批，会读成「这个市有 4811 条资费」——比不给这个档更糟。
#   （与 `#sc` 维度「取不到的档就置灰」是同一条原则：宁可让入口不存在，也不给假答案。）
#   它的数据并入保定（定州原属保定）/ 石家庄（辛集原属石家庄）。
# 「专属区域」：没有独立地市码的行政/功能区，只能从文案里认出来。
#   雄安新区在**移动**那网就是这样（移动的 12 个码里没有雄安）；联通侧它有码
#   （CITY_CODES 里的 782），两条路最后都产出同一个名字 —— 这是刻意的：
#   名字一致，数据对账 / CI 断言才不会把同一个地方当成两个。
CITY_EXTRA = ("雄安新区", "华北油田")
CITY_ALL = frozenset(CITY_ORDER) | frozenset(CITY_EXTRA)
# 允许「从文案里认地市」的网。
#   ★ 只有移动 / 电信：这两网的 applicableArea 覆盖不全（雄安新区 / 华北油田这类区域
#     根本没有码），而它们的文案写地市是可靠信号（实测移动文本兜底命中 373 条）。
#   ★ 联通**不在此列**：它每条资费都带回采集侧的城市归属，没标到的就是全省通用；
#     再从文案里认一遍反而会把实为全省的资费错标成某个市（下拉里就会少掉「全省通用」）。
#     广电上游没有地市粒度，更不该猜。
CITY_TEXT = frozenset(("move", "telecom"))
# ★★ 有「条目级地市维度」的网 —— 只有它们的条目才需要区分
#   「限定地市」（写 `cty`）与「不限地市」（写 `pw=1`，页面「仅全省通用」档读它）。
#   ★ 广电**不在此列**：上游区域码表只有「全国 / 河北省」两档，条目里没有地市，
#     页面上这一层整层隐藏（判据是「本网有没有 cty」，与这里同源）。
#   🔴 这个集合与**数据**必须一致，两个方向都有判据兜着（audit_data.check_city）：
#      在集合里却产不出任何 cty ⇒ 采集侧断了，页面会静默藏掉整个维度；
#      不在集合里却出现了 cty / pw ⇒ 有人漏把它加进来。
CITY_NETS = frozenset(("move", "telecom", "unicom"))
# 文案兜底的判据（与 CITY_ORDER / CITY_EXTRA 配对）；只在 code in CITY_TEXT 时用。
TEXT_CITY_LS = ("石家庄", "唐山", "秦皇岛", "邯郸", "邢台", "保定",
                "张家口", "承德", "沧州", "廊坊", "衡水")
TEXT_CITY_ALIAS = (("雄安新区", "雄安"), ("华北油田", "华北油田|华油"))
HB_PROV_TOK = "HE"           # 2 字母省码 = 河北
HB_PROV_NUM = "311"          # 数字省码 = 河北
CN_TOK = "000"               # 全国标记
SCOPE_CN = {"hb": "河北", "cn": "全国"}

# ── 类型归一：四网「原始分类」→ 统一大类 ─────────────────────────────
# 需求：「分为河北省资费和全国资费…个人资费下面是什么套餐啊、加装包啊…四网都要这样」。
# 但四网的原始分类**根本不同构**（2026-09-22 实测）：
#   移动：加装包 / 营销活动 / 套餐 / 标准资费 / 港澳台-国际资费
#   联通：停售套餐 / 标准资费 / 加装包 / 套餐 / 港澳台-国际资费 / 营销活动
#   电信：加装包 / 营销活动 / 套餐
#   广电：5G套餐 / 促销 / 流量包 / 语音包 / 宽带 / 5G / 4G套餐 / 合约   ← 完全另一套
# 直接拿 `ty` 当筛选项，等于让用户按「上游怎么分类」去理解 —— 四个网四个说法，
# 「套餐」这个词在广电那网甚至不存在。所以在这里显式归一到大类。
# ★ 映射表**列全**而不是靠关键字猜：「5G」这种名字里没写「套餐」的也得进套餐；
#   靠 in 判断「包」字会把「套餐」也误吸进「加装包」。漏映射的会落到「其他」，
#   并由 CI 硬断言把它揪出来（见 .github/workflows/tariff-daily.yml）——
#   宁可停下让人看一眼，也不要页面里悄悄多出一个含义不明的分类。
CAT_ORDER = ("套餐", "加装包", "营销活动", "标准资费", "宽带", "港澳台/国际", "其他")
TYPE_CAT = {
    # 套餐族：广电的「5G / 4G套餐」本质都是主套餐
    "套餐": "套餐", "5G套餐": "套餐", "4G套餐": "套餐", "5G": "套餐",
    # 联通的「停售套餐」就是停了售的套餐；是否停售已由「已下架」页签表达，
    # 不该再占一个大类（否则「已停售」会成为联通独有的大类，四网又不同构了）
    "停售套餐": "套餐",
    # 加装包族：广电的「流量包 / 语音包」就是加在主套餐上的包（移动把它们并称「加装包」）
    "加装包": "加装包", "流量包": "加装包", "语音包": "加装包",
    # 🔴 「合约」是营销活动的子分类，不是套餐（2026-10-03 修，用户发现面板
    #   广电「河北资费→营销活动」只有 6 个而上游有 7 个）：
    #   广电分类树 GZ_YXHD（营销活动）下挂 GZ_YXHD_HY（合约）与 GZ_YXHD_CX（促销）
    #   两个子类 —— 按字面把「合约」当主套餐，河北在售的「奔马卡回馈活动」
    #   「用户回馈活动」2 条就被静默错归「套餐」，营销活动少了 2 条。
    #   佐证：名字全是「XX回馈活动」（全国档同款还有奔马卡/升龙卡等系列活动）。
    "合约": "营销活动",
    "营销活动": "营销活动", "促销": "营销活动",
    "标准资费": "标准资费",
    # 电信集团公示的一级栏目（ct_monitor._normalize_jt），与省级同类不同源
    "国内（不含港澳台）标准资费": "标准资费",
    # 🔴 集团栏目名与省级**词序相反**（省级「港澳台/国际资费」）：漏了这条，
    #   集团 280 条国际资费会静默落进兜底「其他」（2026-10-03 首采实测踩到）
    "国际/港澳台资费": "港澳台/国际",
    "宽带": "宽带",
    "港澳台/国际资费": "港澳台/国际",
}


def type_cat(ty):
    """原始分类 → 统一大类。未映射的归「其他」（CI 会断言它为 0）。"""
    return TYPE_CAT.get(str(ty or "").strip(), "其他")


# ── 联通细分规整（2026-10-03 重设计）────────────────────────────────────
# 只动联通：移动/电信/广电的细分本就干净。三条规则见 rows_of 联通分支注释。
# ★ 映射后的取值必须与各**大类从属关系一一对应**（页面 data-cat 依赖它做联动）：
#   「加装包」「移网套餐」只出现在 港澳台/国际 大类下，「移网」只出现在 套餐 下
#   —— 若把「国际/港澳台移网套餐」剥成「移网」，它会同时挂在 套餐 与 港澳台/国际
#   两个大类下，页面的细分↔大类从属表（首次见到的 cat）就会写错、联动误清值。
UC_TY_NORM = {
    "国际/港澳台加装包": "加装包",      # 大类已是「港澳台/国际」，细分剥掉冗余前缀
    "国际/港澳台移网套餐": "移网套餐",  # 同上；保留「套餐」字样避免与套餐大类的「移网」重名
    "其他": "其他加装",                 # 该二级只出现在加装包下；原名与兜底大类「其他」同名
}


# ── 渠道归一：原文 → 线上 / 线下 / 两者都有 ───────────────────────────
# 渠道字段四网都是 100% 填充，但写法极其碎（移动光「线上」就有「线上渠道」
# 「线上及线下渠道」「线上、线下渠道，具体以各省实际为准，详询10086」三种写法；
# 还有「自有渠道（中国联通APP等）、互联网渠道（飞猪、携程等）」这种
# —— 看着像线下，其实是纯线上）。按原文筛毫无意义，归一到三档才有用。
# ★ 判定顺序要紧：先判「两者都有」，再判单一 —— 「线上线下」两个词都命中时
#   若先判单边就会把它误归成其中一边。
# ★ 归属（个人 / 政企）—— 四网里**只有移动**的上游接口带这个字段：
#   条目级 ``type1``（1=个人、2=政企）。联通/电信/广电的条目**根本没有 type1 键**。
#   ★ 2026-09-23 修正：此前「政企四网全不可得 ⇒ 不做政企层」的结论是**错的**。
#     当时拿 applicablePeople（目标客户）文本去猜，四网只捞到 68 条；
#     而真正的判据 type1 一直躺在快照里 —— 它被当成「分类层级」只用于分组，
#     从未落到行数据上，于是「字段在手却判成没有」。参考同类开源项目时才发现。
OW_CN = {"1": "个人", "2": "政企"}
OW_ORDER = ("个人", "政企")

# ── 板块（tariffAttr）：1 = 全国 / 跨省目录，2 = 本省目录 ──────────────
# 四网同义（移动 / 联通 / 广电的采集侧都这么用；见 probes/he_unicom_tariff.py
# 的注释「tariffAttributes：1 = 全国/跨省目录，2 = 本省目录」）。
# 🔴 **电信是例外**：那个适配器把该字段**写死成 "2" 当占位**（ct_monitor.py：
#   「页面不用 a1；与其他网行对齐」，真值另存 _tariffAttrRaw、语义至今未定）。
#   照它落盘，就等于把「这是本省资费」这么一个**我们根本没资格断言的说法**
#   印到页面上 —— 与「地市维度曾因信了数据源自报的 allProvince 而整层消失」
#   是同一类错误的镜像：那次是信了错的声明、这次会是信了一个占位值。
#   ⇒ 判据取**数据**：只有本网该字段**真的出现两个取值**时才落盘这一维。
#     单档维度本身也没有筛选价值（选与不选一个样），宁可不给。
#   ★ "3" = 集团资费（2026-10-03 定）：电信集团公示块（ct_monitor._normalize_jt）
#     恒置 "3"，省级恒 "2" ⇒ 电信 _attrs={2,3} 凑齐两档，「资费范围」自动出现。
#     移动/广电不受影响（它们没有 3，落盘规则照旧）。
ATTR_CN = {"1": "全国资费", "2": "本省资费", "3": "集团资费"}
# 集团公示档的 tariffAttr 值（见 ATTR_CN["3"]）。**唯一权威**：rows_of 靠它决定
# 「不写 pw」（集团目录没有地市概念，写 pw=1 会被「仅全省通用」档照单收进）；
# audit_data.check_city 的三态判据也读它 —— 两边各写一个字面量 "3" 又是一份会漂的副本。
ATTR_GROUP_PUB = "3"

# 联通「停售套餐(99)」—— 它**不是分类，是状态桶**。见 rows_of 里的还原规则。
STOPPED_L1 = "停售套餐"

# 变更历史 —— 逐次追加、不覆盖，是页面「变化历史」时间线的**唯一**数据源。
# changes/*.md 是给人读的长文（含逐条明细），不适合页面解析：正则一改版就全废，
# 而它本身是产物、不是接口。另存一份结构化摘要，两边各干各的。
HIST_FILE = os.path.join(BASE, "history.json")
HIST_KEEP = 400          # 只留最近 400 条「网×批次」（约 100 次巡检，够回溯半年）

CH_ORDER = ("线上", "线下", "线上+线下", "其他")
# 「全渠道 / 全部」这类没点名线上线下的写法，语义就是「两边都能办」——
# 漏进「其他」会让「线上」这一档少掉 120 条（实测移动 15 + 联通 105）。
CH_ALL = ("全渠道", "全部渠道", "全部", "不限渠道", "各渠道", "任何渠道")
CH_ON = ("线上", "在线", "网厅", "掌厅", "官网", "网上", "互联网", "APP", "app", "App",
         "微信", "公众号", "小程序", "外呼", "热线", "10086", "10010", "10000", "10099",
         # 电话/短信/商城/客户端都属自助渠道。联通的「宽视界大屏端」是电视端自办，
         # 也算线上 —— 它不是实体营业厅。
         "电话", "短信", "商城", "客户端", "大屏", "宽视界", "兑换",
         "抖音", "电视端", "IPTV", "会员中心",
         # 「综合平台」是电信集团公示块（attr=3）的主力渠道写法（实测 157 条），
         # 它是网上/平台自助办理 —— 不认的话整批落「其他」，CI 渠道占比闸门就红
         #（2026-10-04 run #50 实测：其他 160 条 > 2% 阈值）。
         "综合平台")
CH_OFF = ("线下", "营业厅", "门店", "实体", "社会渠道", "代理", "自有渠道",
          # 校园/合作/指定/代办/装维都是要去实体点或由人上门办的
          "校园", "合作", "指定", "装维", "自办厅", "代办", "加盟",
          "网点", "厅店", "客户经理")


def ch_norm(s):
    """渠道原文 → 归一档。认不出的归「其他」并原样保留在页面（可搜可看）。"""
    t = str(s or "").strip()
    if not t:
        return "其他"
    if any(k in t for k in CH_ALL):
        return "线上+线下"
    on = any(k in t for k in CH_ON)
    off = any(k in t for k in CH_OFF)
    if on and off:
        return "线上+线下"
    if on:
        return "线上"
    if off:
        return "线下"
    return "其他"


def _uniq(seq):
    """保序去重（地市码可能同时出现在 applicableArea 与 city 两个字段里）。"""
    out, seen = [], set()
    for x in seq:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def _toks(v):
    return [t.strip() for t in str(v or "").split(",") if t.strip()]


def _mk_cities(codes):
    """4 位地市码列表 → 统一中文名列表（去重、丢掉码表里没有的）。"""
    return _uniq([HB_CITY[t] for t in _uniq(codes) if t in HB_CITY])


def text_cities(e):
    """从**文案**里认地市 —— 只给 ``CITY_TEXT`` 里那两网用（见常量注释）。

    返回中文名列表（可为空）。四个字段取**并集**，缺一不可，这是实测的：
      · 只看名称 → 漏 46 条：地市只写在「目标客户」里的「移动云盘2026特惠季包」（秦皇岛）
      · 只看「目标客户」→ 漏 103 条：市级包名带地市、但该字段只写通用话术的
        「邯郸179元低消回馈」「秦皇岛10元语音低消」…
    返回数组而非单值：一条可属多市（IPTV 类在目标客户里列 4 个市；
    「沧州华油尊享礼包」同属沧州与华北油田）。
    """
    s = " ".join(str(e.get(k) or "") for k in ("name", "tariffName",
                                               "applicablePeople", "otherContent"))
    out = [c for c in TEXT_CITY_LS if c in s]
    for name, pat in TEXT_CITY_ALIAS:
        if re.search(pat, s):
            out.append(name)
    return _uniq(out)


def _mv_where(e):
    """移动条目地域 → ``(sc, cities)``（cities 是**中文名**）。

    ``sc``      ``"hb"`` 河北 / ``"cn"`` 全国 / ``""`` 与河北无关（整条丢弃）
    ``cities``  地市名列表（空列表 = 全省通用）。一条资费可覆盖多个市（CSV），
                也可能同时出现在 `applicableArea` 与 `city` 两个字段里 ⇒ 去重。

    ★ 判序要点：**地市码优先于全国码**。实测有条目 `applicableArea` 同时含
      地市码与 `000`，它的语义是「这个市里按全国资费执行」⇒ 归地市更具体。
    """
    aa, ct, pv = _toks(e.get("applicableArea")), _toks(e.get("city")), _toks(e.get("province"))
    # ★★ 「全省通用」有**两种**写法，第二种以前没被识别（2026-09-24 修）：
    #     ① applicableArea / city 留空                     → 无地域限制
    #     ② 把**全部 12 个地市码**都列出来（实测常整串重复两遍）→ 覆盖面就是全部地市
    #   ② 若直接走下面的 _mk_cities，会被映射成 12 个市名 ⇒ 判成「12 城专属」：
    #     这批（实测移动 59 条，多是「0预存5G金币购机合约活动」这类全省活动）
    #     既不在「仅全省通用（不限地市）」档里，又被计进「地市专属」总数。
    #   判据用「码集合 ⊇ 全部地市码」而不是「token 数 ≥ 12」—— 后者会被重复 token
    #   或非地市码骗到；只有真的覆盖全 12 个码才算全省。
    #   ⚠️ 电信那批「11 个 / 10 个码」**不适用**本判据：实测它们确实只限那几个市
    #     （农业/扶贫/宽带政策类，少的正是廊坊、唐山等），不能算全省。
    if HB_CITY_CODES <= set(_uniq(aa + ct)):
        return "hb", []
    cities = _mk_cities(aa + ct)
    if cities:
        return "hb", cities
    if CN_TOK in aa:
        return "cn", []
    # `!AH` / `!AH,!HI` = 「除这些省以外」，语义上等效全国（实测 12 条）
    if any(t.startswith("!") for t in aa):
        return "cn", []
    letters = [t for t in aa if len(t) == 2 and t.isalpha()]
    if len(letters) >= 2:                      # 多省 CSV
        return ("cn", []) if HB_PROV_TOK in letters else ("", [])
    if len(letters) == 1:
        return ("hb", []) if letters[0] == HB_PROV_TOK else ("", [])
    if len(pv) >= 2:                           # province 侧的多省数字码列表
        return ("cn", []) if HB_PROV_NUM in pv else ("", [])
    if len(pv) == 1:
        return ("hb", []) if pv[0] == HB_PROV_NUM else ("", [])
    if ct and all(t in HB_CITY for t in ct):
        return "hb", _mk_cities(ct)
    if not aa and not ct and not pv:           # 三字段全空 = 无地域限制 ⇒ 全省通用
        return "hb", []
    return "", []


def _ct_where(e):
    """电信条目地域 → ``(sc, cities)``（cities 是**中文名**）。

    ★ 整套电信数据的 provCode 就是 609906（河北），所以**默认 hb 是保守且正确的**；
      只有条目自己声明了地市码时才细分（`applicableArea` 是 CSV，含 3190 即邢台）。
      这里读的是 ct_monitor 归一化时特意保留的 `_areaCodes`（原来是丢掉的）。

    ★ 「全部 12 个地市码都列出来」= 全省通用，与 `_mv_where` 同一判据（见那边的注释）。
      实测电信这批（10~11 个码）**不是**全省 —— 它们确实只限那几个市，所以本判据
      只在**恰好覆盖全 12 码**时生效，不会误伤。
    """
    toks = _toks(e.get("_areaCodes"))
    if HB_CITY_CODES <= set(_uniq(toks)):
        return "hb", []
    return "hb", _mk_cities(toks)


def _uc_where(e):
    """联通条目地域 → ``(sc, cities)``（cities 是**中文名**）。

    联通**没有地域字段**，但采集侧有 —— 12 城并集采集时，每条资费都带回了
    「它的三级目录出现在哪些城市」（见 probes/he_unicom_tariff.collect）：

      · ``_cityNames``：城市名列表，**没有**覆盖全部城市 ⇒ 只在这些城市的目录里；
      · ``_allCity=1``：覆盖了全部城市 ⇒ 全省通用（采集侧刻意不落列表，见那边注释）。

    🔴 这里读的键必须在**采集侧**就被换成中文名（同 CITY_ORDER / CITY_EXTRA 那套）。
      不要在这边另配一张「联通 3 位码 → 名字」的表 —— 两张表要同步，而它们迟早会漂。

    ⚠️ 老快照（2026-09-24 之前采的）两个键都没有 ⇒ 一律按「全省通用」渲染，
      页面因此**不出地市这一层**（它按「有没有 cty」判）。这是刻意的 fail-safe：
      数据里没有地市信息时，宁可不给这个维度，也不要拿一个不存在的维度去筛
      （用户选「邢台」会得到 0 条，而那看起来像「邢台没有资费」）。
    """
    return "hb", _uniq([n for n in (e.get("_cityNames") or []) if n in CITY_ALL])


def _cbn_where(e):
    """广电条目地域 → ``(sc, cities)``。

    广电在上游只有「全国 / 河北省」两档地区 —— 条目里**没有地市字段**，所以 cities
    恒空：四网里唯一不出地市维度的一家（页面按「有没有 cty」判，自动不出这一层）。
    （原来这是个匿名 lambda，提成具名函数是为了让四网注册表能挂上它、并被对拍。）
    """
    return (("cn" if "全国" in str(e.get("_areaNames") or "") else "hb"), [])


# ════════════════════════════════════════════════════════════════════════
# 四网注册表 —— 每一网的「全部知识」收在一个对象里
# ════════════════════════════════════════════════════════════════════════
# ★ 为什么要有这一层（2026-09-26 模块化）：
#
#   重构前，**同一网**的属性散在 8 张平行表 + 3 处 ``if code ==`` 分叉里：
#     NETS_META（页签显示名）/ SRC_OF（来源）/ NET_LIVE（采不采）/ NET_SNAP（兜底名单）/
#     SNAP_PREFIX（快照前缀）/ NET_RUN（适配器 + 报告前缀）/ NET_STOPPED（支持停售）/
#     NET_NOCACHE（不进本地缓存），外加 WHERE_OF（地域判据）、state_of 里的
#     ``if code == "unicom"``、snap_net_ready 里的 ``if code != "telecom"``。
#
#   接一条新网要**同时改 8~10 处**，而漏一处的症状各不相同、**都不报错**：
#     · 漏 NET_SNAP     ⇒ 该网采不到时页面直接少一网（不报错，只是少）
#     · 漏 SNAP_PREFIX  ⇒ 它的快照与别网混进同一个 load_prev 排序，
#                         拿别网的数据当自己的基准（数字全错，且看不出原因）
#     · 漏 NET_RUN      ⇒ 该网永远不会被采集（页面显示 0 条，看着像上游没数据）
#   本层把「一网的属性」收进一个类 ⇒ **加一条新网 = 加一个类 + 注册一行**。
#
# ★ 本层**不搬采集代码**：移动的直连采集（fetch_group / fetch_all / call）留在本文件，
#   另三网的归一化层仍是 X_monitor.py —— 它们各被 rebuild_offline.py 与 probes/ 下的
#   探针直接 ``__import__`` 引用，合并进来只会把那些调用点一起打断。
#   本层管的是**注册与派发**（谁、怎么采、采不到怎么办、地域与下架怎么判）。
#
# ★ 8 张老表**全部保留**（在文件下方原位，改成由注册表派生）—— 外部有 4 个脚本在读它们：
#   rebuild_offline.py 解包 ``NET_RUN`` 三元组、probes/check_area_scope.py 与
#   probe_scope_state.py 读 ``SNAP_PREFIX``/``where_of``、selftest_pipeline.py 读 ``NET_SNAP``。
#   删掉任何一个都是**静默断链**：那些脚本不会报错，只会少采 / 采错。
#   tools/check_nets_refactor.py 负责逐项对拍派生视图与重构前的原值。
class NetSource:
    """一网的「全部知识」—— 采集方式、显示名、快照前缀、兜底策略、地域与下架判据。

    字段刻意写成**类属性**而不是构造函数参数：这张表是新人理解本仓库的入口，
    必须能一眼静态读完。实例只承载行为（fetch / where / stopped_of / ready）。
    """
    code = ""              # 机器名（快照文件名、diff 键、快照前缀都用它）
    sh = ""                # 页面短名（页签、顶部提示语）
    cn = ""                # 报告与推送里的全名
    vendor = ""            # 供应商全名（页签 title）
    tag = ""               # 变更报告文件名前缀；空 = 直接 ``{日期}.md``（移动）
    snap_prefix = ""       # 本网独立快照前缀 —— 各网必须各存各的：
                           # load_prev 按**文件名排序**取「最近一份」，混用前缀会让
                           # A 网拿去 B 网的快照当基准（2026-09-22 的坑：数字全错）
    src = ""               # 页面顶部「来源」行（用户向的展示名）
    src_tech = ""          # 技术溯源（接口域名 / 路径）—— 只进 docs 与变更报告，不进页面
    mod = ""               # 适配器模块名；空 = 采集实现就在本文件（移动）
    stopped = False        # 适配器 fetch_all 是否接受 include_stopped
    nocache = False        # 「纯本地转换」网（不发请求、读采集产物）⇒ 不进本地缓存
    fallback = "prev"      # 采不到时兜底用哪份快照："prev" 严格早于今天 / "latest" 最新一份
    live = True            # 是否进每日巡检

    def fetch(self):
        """采集并归一化成 ``{groups|entries}`` 同构结构。

        ★ 默认走**适配器模块**（``mod``）；采集实现就在本文件的网（移动）覆写本方法。
        ★ 异常不在这里兜 —— 由调用方 net_round 统一接住，因为它还要决定
          「退回哪一份快照」（见那边的 ``fallback`` 分支）。
        """
        m = __import__(self.mod)
        return m.fetch_all(include_stopped=True) if self.stopped else m.fetch_all()

    def where(self, e):
        """条目地域 → ``(sc, cities)``。默认全省（宁可多留，不可静默丢）。"""
        return "hb", []

    def stopped_of(self, e, g, base_day):
        """该条目是否「已下架」。默认 False = 本网没有下架信号。"""
        return False

    def ready(self, today):
        """本轮采集产物是否就绪。默认 True —— 直连的网没有「产物」这一步。"""
        return True


class MoveNet(NetSource):
    """移动：nrapigate 直连，**采集实现就在本文件**（``fetch_group`` / ``fetch_all``）。

    ★ 四网里唯一「没有适配器模块」的一家：它的字段布局是本仓库的原生口径，
      另三网的 X_monitor.py 都是**往这套字段上对齐**（见各自的 FIELD_MAP）。
    ★ 拿不到下架数据：``isPublic='0'`` 的分类能列出来，但明细接口恒返回 0 条
      ⇒ ``stopped_of`` 恒 False —— 不是「懒得判」，是本网真的没有这个信号。
    """
    code, sh, cn, vendor = "move", "移动", "河北移动", "中国移动"
    snap_prefix = "hebei_tariff_"
    # src = 页面「来源」行显示的名字（用户向：别放接口主机名 / 路径）；
    # src_tech = 技术溯源，只进 docs 与变更报告。
    src = "中国移动 APP「资费专区」"
    src_tech = "nrapigate / nrtariff（h.app.coc.10086.cn）"
    where = staticmethod(_mv_where)

    def fetch(self):
        return fetch_all()               # 本文件内置那套直连采集


class UnicomNet(NetSource):
    """联通：一级分类 ``99``「停售套餐」= 已下架（不靠日期判，见 stopped_of）。"""
    code, sh, cn, vendor = "unicom", "联通", "河北联通", "中国联通"
    tag = "unicom"
    snap_prefix = "unicom_tariff_"
    src = "中国联通 APP「资费专区」"
    src_tech = "mxx.client.10010.com / queryTariffNew"
    mod = "unicom_monitor"
    stopped = True
    where = staticmethod(_uc_where)

    def stopped_of(self, e, g, base_day):
        # 🔴 只能用「被归到 99 类」这个信号，**不能看 endDate**：
        #    实测那批 endDate 一条都没过期（初版注释写的「99.87% 已过期」已不成立）——
        #    它被归到 99 类这件事本身就是唯一下架证据。
        return str(g.get("type2")) == "99" or str(e.get("_firstLevel")) == "99"


class TelecomNet(NetSource):
    """电信：四网里唯一的**机会性采集** —— 需要真实浏览器，采不到就退回快照。

    ★ ``fallback = "latest"``（不是默认的 "prev"）：本轮没采到时该用**最新那份**快照
      （可能就是今天早些时候采的），而不是「严格早于今天」的那份 ——
      否则明明仓库里有今天的数据，页面却退回昨天。
    ★ ``nocache``：适配器是**纯本地转换**（读 ``.ct_raw.json``，不发请求），
      缓存它没有收益、只有风险：采集产物更新了而缓存还是旧的，本地重建看不出这一点
      （2026-09-23 实测踩到：``.telecom_cache.json`` 停在 09-22，重跑采集也不会被用上）。
    """
    code, sh, cn, vendor = "telecom", "电信", "河北电信", "中国电信"
    tag = "ct"
    snap_prefix = "ct_tariff_"
    src = "中国电信「资费专区」"
    src_tech = "www.189.cn / tariffSection（真实浏览器采集）"
    mod = "ct_monitor"
    nocache = True
    fallback = "latest"
    where = staticmethod(_ct_where)

    def stopped_of(self, e, g, base_day):
        # 本网**没有**独立状态位，只能看下线日是否早于基线日。
        # 8 位日期按字符串比较即是按时间比较；格式不对一律当在售（宁可漏判不可误判）。
        d = str(e.get("offineDay") or "").strip()
        return bool(re.fullmatch(r"\d{8}", d)) and d < str(base_day or "").replace("-", "")

    def ready(self, today):
        """本轮是否真拿到了浏览器采集产物 —— 决定走采集还是走快照。

        ★ 判据是**采集产物里记录的日期**，不是「文件在不在」：``.ct_raw.json`` 不入库，
          但本机那份可能是上周采的，光看存在就走采集，会拿一份陈旧数据当今日快照入库
          （还会连带生成一份「电信无变化」的假报告）。用 mtime 更糟 ——
          CI 每次都是全新 checkout，mtime 恒为「现在」，等于恒真。
        """
        try:
            ct = __import__("ct_monitor")
        except Exception as e:
            log(f"!! 电信适配器不可用（{type(e).__name__}: {e}），本轮改用快照渲染")
            return False
        d = ct.raw_day()
        if d == today:
            return True
        log(f"-- 电信本轮没有新采到的原始数据"
            f"（.ct_raw.json 记录的采集日 {d or '（无文件）'} ≠ 今天 {today}），改用快照渲染")
        return False


class CbnNet(NetSource):
    """广电：服务端状态位 ``stateFlag``（``1`` 在售 / ``0`` 下架）；地域只有全国/河北两档。"""
    code, sh, cn, vendor = "cbn", "广电", "中国广电", "中国广电"
    tag = "cbn"
    snap_prefix = "cbn_tariff_"
    src = "中国广电「资费公示」"
    src_tech = "m.10099.com.cn / queryTariffAllByCond"
    mod = "cbn_monitor"
    stopped = True
    where = staticmethod(_cbn_where)

    def stopped_of(self, e, g, base_day):
        return str(e.get("stateFlag") or "1") != "1"


# 注册表本体：顺序 = 接入顺序（move 最先，也是唯一「采集实现就在本文件」的网）。
NETS = {s.code: s for s in (MoveNet(), UnicomNet(), TelecomNet(), CbnNet())}

# ★ 三个顺序元组刻意分开 —— 它们的历史来源不同，**不要为了整齐合并成一个**：
#   _PAGE_ORDER 决定页面页签与「来源」的顺序（NETS_META / SRC_OF 用）；
#   _RUN_ORDER  决定每日巡检的采集顺序与顶部提示语的拼接顺序（NET_LIVE / SNAP_PREFIX 用）；
#   _WHERE_ORDER 是 WHERE_OF 这个 dict 自己的键顺序（先写的移动与电信，后补联通）。
#   三者在 telecom/cbn 上互不相同，全是历史遗留。
#   顺序对查表**没有**影响，但它是可观察的（谁遍历这个 dict，输出顺序就跟着变），
#   而 check_nets_refactor.py 会逐项比 —— **照原样钉住，不留「这个差异无害」的例外**：
#   一旦允许一个例外，下一个就没人核了。（首轮对拍确实在这里报了一次红。）
_PAGE_ORDER = ("move", "unicom", "telecom", "cbn")
_RUN_ORDER = ("move", "unicom", "cbn", "telecom")
_WHERE_ORDER = ("move", "telecom", "unicom", "cbn")

WHERE_OF = {c: NETS[c].where for c in _WHERE_ORDER}


def where_of(code, e):
    """取条目的地城归属 ``(sc, cities)``；未知网返回 ``("hb", [])``（宁可多留，不可静默丢）。"""
    f = WHERE_OF.get(code)
    return f(e) if f else ("hb", [])


def scope_of(code, e):
    """兼容包装：只要 ``sc``（``hb`` / ``cn`` / ``""``）。"""
    return where_of(code, e)[0]

HEADERS = {
    "Content-Type": "application/json; charset=UTF-8",
    "User-Agent": UA,
    "Origin": "https://h.app.coc.10086.cn",
    "Referer": REF,
    "x-requested-with": "com.greenpoint.android.mc10086.activity",
    "x-qen": "1",
    "x-app-version": "1.0.2",
    "channelid": "CHINA_APP",
}


def _ssl_ctx():
    """移动 nrapigate 服务器**不支持 RFC5746 安全重协商**。

    OpenSSL 3.x 默认拒绝这类旧式服务器，报
      `[SSL: UNSAFE_LEGACY_RENEGOTIATION_DISABLED] unsafe legacy renegotiation disabled`
    （GitHub Actions 上 curl+OpenSSL 3.0.13 会同样报错：`OpenSSL error:0A000152`）。
    必须显式打开 SSL_OP_LEGACY_SERVER_CONNECT（值 0x4）才能握手成功。

    注意：本机 Windows 用 curl 能连通，是因为它走 **Schannel**，不检查这一项 ——
    所以这个坑只在 Linux / Python 侧暴露，别被"本地能跑"误导。
    """
    ctx = ssl.create_default_context()
    ctx.options |= getattr(ssl, "OP_LEGACY_SERVER_CONNECT", 0x4)
    return ctx


# 显式传空 ProxyHandler：否则 urllib 会自动补一个默认的，其代理来自环境变量
# 与 Windows 注册表 Internet 设置（残留代理会静默劫持请求）。空 dict = 真直连。
_OPENER = urllib.request.build_opener(
    urllib.request.HTTPSHandler(context=_ssl_ctx()),
    urllib.request.ProxyHandler({}),
)

for d in (SNAP, CHG, DOCS):
    os.makedirs(d, exist_ok=True)

KEY_FIELDS = ["fees", "data", "dataUnit", "call", "applicablePeople", "channel",
              "onlineDay", "offineDay", "otherContent", "extraFees", "validPeriod",
              "brandwidth"]
FIELD_CN = {"fees": "月费", "data": "流量", "dataUnit": "流量单位", "call": "通话",
            "applicablePeople": "目标客户", "channel": "办理渠道",
            "onlineDay": "上线日", "offineDay": "下线日",
            "otherContent": "权益说明", "extraFees": "超套资费",
            "validPeriod": "有效期", "brandwidth": "宽带"}


def log(msg):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def _unwrap_payload(j):
    """网关响应的统一拆壳：`{"body": "<密文>"}` -> 解密 -> dict。

    抽成独立函数的原因：fetch_group / 各探针 / 公告通道都要走同一套壳判定
    （`set(keys)=={"body"}`），散着写的话哪天上游加一个签名字段（变成
    `{"body":..., "sign":...}`）就得改 N 处。
    """
    if isinstance(j, dict) and "body" in j and isinstance(j["body"], str):
        if mz_crypto is None:
            raise RuntimeError("响应带加密壳但缺少加解密依赖 pycryptodome")
        j = json.loads(mz_crypto.decrypt(j["body"]))
    return j


def call(path, body, retry=2, cap=8.0, ua=None):
    """调网关：POST 明文 JSON -> 若响应是 {"body": "<密文>"} 则本地解密 -> dict

    ``ua``：本轮请求的 UA 覆写（UA 指纹池轮换用，见 ``UA_POOL``）；
    ``None`` = 用模块级 ``HEADERS`` 的默认 UA（探针等既有调用方零改动）。

    🔴 失败契约：打不通时返回 ``{"_err": "<分类前缀>: 详情"}``，**绝不抛异常**
       —— 调用方（fetch_group / 各探针）靠 ``_err`` 区分「没问到」和「没数据」
       （见 probe_coverage_axes._transport_failed）。分类前缀：
         · ``net:``    连接层（DNS / 路由 / 超时）—— 重跑可自愈
         · ``http:NNN:`` 拿到了 HTTP 状态但不是 200（412 = 瑞数类挑战，网关被封；
                         5xx = 服务端抽风）
         · ``body:``   200 但不是合法 JSON / 不是预期结构 —— 上游改版信号
    退避：指数 + 全抖动（``sleep = rand(0, min(cap, base*2**i))``）。固定间隔的
    问题是并发抓取时所有线程同拍重试，形成自愈不了的节奏性拥堵；抖动让重试散开。
    cap 默认 8s：单页明细调用方多（并发线程各自重试），退避太长会把整轮拖垮；
    单点依赖（如 getType2List，整轮都等它）应传更大的 cap —— 见 fetch_all。
    """
    if mz_crypto is None:
        return {"_err": f"缺少加解密依赖 pycryptodome（{_MZ_ERR}），只能跑 --render-only"}
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    last = None
    for i in range(retry + 1):
        try:
            headers = HEADERS if ua is None else {**HEADERS, "User-Agent": ua}
            req = urllib.request.Request(ROOT + path, data=data,
                                         headers=headers, method="POST")
            with _OPENER.open(req, timeout=25) as r:
                # 读上限兜底：单页响应正常 < 几 MB，超过 64MB 必是异常（坏网关把
                # 错误页/重定向流吐回来），别真往内存里塞（2026-10-02 审查项）。
                raw = r.read(64 * 1024 * 1024 + 1)
            if len(raw) > 64 * 1024 * 1024:
                raise ValueError("单页响应超过 64MB 上限")
            txt = raw.decode("utf-8", "replace").strip()
            j = _unwrap_payload(json.loads(txt))
            return j
        except urllib.error.HTTPError as e:
            body_txt = ""
            try:
                body_txt = e.read(4096).decode("utf-8", "replace").strip()
            except Exception:
                pass
            hint = "（瑞数类 JS 挑战：网关侧风控，纯 HTTP 短期内打不通）" if e.code == 412 else ""
            last = f"http:{e.code}: {e.reason} {hint} {body_txt[:120]}".strip()
            log(f"  !! call({path}) 第{i + 1}次 HTTP {e.code}{hint}")
        except (urllib.error.URLError, OSError, ssl.SSLError, TimeoutError) as e:
            last = f"net: {type(e).__name__}: {e}"
            log(f"  !! call({path}) 第{i + 1}次网络异常: {last[:130]}")
        except Exception as e:
            # JSON 解析失败 / 解密失败 —— 200 但内容不对，多半是上游改版或密钥漂移。
            # 这类**不值得原样重试**（同样的请求拿同样的坏响应），但仍重试一次防抖动截断。
            last = f"body: {type(e).__name__}: {e}"
            log(f"  !! call({path}) 第{i + 1}次响应异常: {last[:130]}")
        if i < retry:
            # 指数退避 + 全抖动：base 1.5s，上限 cap（默认 8s，单点依赖可传大）
            time.sleep(random.uniform(0, min(cap, 1.5 * (2 ** i))))
    return {"_err": last}


def _declared(b):
    """系列声明的明细条数 = nonModuleListTotal + moduleListTotal；取不到返回 None。"""
    try:
        n, m = b.get("nonModuleListTotal"), b.get("moduleListTotal")
        if n is None and m is None:
            return None
        return int(n or 0) + int(m or 0)
    except (TypeError, ValueError):
        return None


def fetch_group(c, ua=None, ua_i=None):
    """抓一个分类组合（含分页与系列对账）。

    ``ua`` / ``ua_i``：UA 指纹池轮换（见 ``UA_POOL``）—— 每个组合固定拿一个
    UA = 独立限流配额池；日志带上 ``ua#N`` 便于排查「哪一栏触发了限流子集」。
    """
    a, t1, t2v = str(c.get("tariffAttr")), str(c.get("type1")), str(c.get("type2"))
    entries, beans_all, page, total, fails = [], [], 1, None, 0
    short, miss_eg = 0, []
    while True:
        # ★★ fistLimit = **每个系列最多返回多少条明细**（不是外层分页大小！）
        #   默认传 100 时，条目数 >100 的系列会被静默截断（2026-09-23 实锤：
        #   attr=1/t2=4 某个系列声明 178 条只回 100；全网加装包某系列声明 244 只回 100）。
        #   ⇒ 传 5000（实测 0 / 1000 / 5000 拿到的条数一致且等于上游声明数）。
        #   limit=100 才是外层「每页几个系列」，page 翻的是系列页。
        lst = call("nrtariff/new/Tariff/getTariffListInfo",
                   {"cellNum": "", "province": PROV, "isPublic": "1", "linkScn": "2",
                    "tariffAttr": a, "type1": t1, "type2": t2v,
                    "page": page, "limit": 100, "fistLimit": 5000}, ua=ua)
        d = lst.get("data") if isinstance(lst, dict) else None
        if not isinstance(d, dict):
            fails += 1
            log(f"  !! attr={a} t1={t1} t2={t2v} page={page} 异常: {str(lst)[:150]}")
            break
        for b in d.get("beans") or []:
            # ★★ 一个系列下的明细有**两种容器**，只取 nonModuleList 会整栏漏采：
            #   nonModuleList          —— 大多数栏目走这里
            #   moduleList[].tariffList —— 「模组化」资费走这里（上游另有 moduleListTotal
            #                              / nonModuleListTotal 两个计数，本来就是并列的两种）
            #   2026-09-23 实锤：attr=1/type2=4（全网资费·港澳台国际专区）34 个系列的
            #   **1240 条全在 moduleList**，nonModuleList 恒空 ⇒ 页面这一栏一直是 0 条，
            #   而且因为「枚举组合是对的、接口也 200」，日志里完全看不出异常。
            #   全量核对：18 个组合里 4 个有 moduleList，合计 1257 条（占当时总量 32.6%）。
            # ★ 两类容器**互斥**（按 (name, reportNo) 求交集 = 0），可直接拼接、无需去重。
            en = list(b.get("nonModuleList") or [])
            n_mod = 0
            for m in b.get("moduleList") or []:
                tl = m.get("tariffList") or []
                n_mod += len(tl)
                en.extend(tl)
            entries.extend(en)
            beans_all.append({"tariffSeqno": b.get("tariffSeqno"),
                              "tariffName": b.get("tariffName"), "count": len(en),
                              "nonModule": len(en) - n_mod, "module": n_mod,
                              "declared": _declared(b)})
            # ★★ 对账守卫：上游**每个系列**都带 nonModuleListTotal / moduleListTotal。
            #   声明数 ≠ 实取数 ⇒ 要么还有第三种容器没消费，要么 fistLimit 又截断了。
            #   这个判据比外层的 data.page.total 精确得多：
            #   上面 moduleList 整栏漏采（1240 条）和 fistLimit 截断（单系列 244→100）
            #   在旧逻辑下**接口都返回 rc=0、外层 total 也正常**，只有这里能照出来。
            dec = _declared(b)
            if dec is not None and dec != len(en):
                short += max(0, dec - len(en))
                if len(miss_eg) < 5:
                    miss_eg.append(f"{b.get('tariffSeqno')}:{len(en)}/{dec}")
        pg = d.get("page") or {}
        total = pg.get("total")
        pages = pg.get("pages") or 1
        if page >= pages:
            break
        page += 1
    n_mod_all = sum(b.get("module") or 0 for b in beans_all)
    log(f"  attr={a} t1={t1} t2={t2v} total={total} series={len(beans_all)} "
        f"entries={len(entries)} (其中 moduleList={n_mod_all}) fails={fails}"
        + (f" ua#{ua_i}" if ua_i is not None else "")
        + (f"  ⚠️ 缺 {short} 条 例 {miss_eg}" if short else ""))
    return {"tariffAttr": a, "type1": t1, "type2": t2v, "total": total,
            "series": beans_all, "entries": entries, "short": short}


def fetch_all(workers=4):
    t0 = time.time()
    # 🔴 分类列表是整轮的**单点依赖**：后面每个组合都由它展开，它拿不到 =
    #    整轮巡检报废（电信白采 / 页面不重建 / 部署 skip）。
    #    2026-10-03 一天两遇（run #43 明细接口、#44 分类接口，均为 GitHub 服务器
    #    到移动网关的 Errno 101 Network is unreachable）：call() 内部的 3 连试 +
    #    ≤8s 退避，每次还被 ~25s 的连接超时占着，桥不过分钟级的路由抖动窗。
    #    这里给专项长重试：6 轮、退避上限 30s，最坏 ~5 分钟——分钟级的抖动
    #    基本都能跨过去。敢这么等的底气是 call 的 _err 契约把「网络不可达」
    #    与「上游确实没数据」分得清清楚楚：后者不值得等，直接走失败分支。
    t2 = {"_err": "net: 首轮（尚未请求）"}
    for rnd in range(6):
        t2 = call("nrtariff/new/Tariff/getType2List",
                  {"province": PROV, "isPublic": "1"}, retry=3, cap=30.0)
        if not (isinstance(t2, dict) and t2.get("_err")):
            break
        if rnd < 5:
            log(f"  分类列表第{rnd + 1}轮不可达（{str(t2.get('_err'))[:110]}），"
                f"歇 20s 再来一轮")
            time.sleep(20)
    combos = (t2.get("data") if isinstance(t2, dict) else None) or []
    if not combos:
        log(f"分类列表获取失败: {str(t2)[:200]}")
        return None
    log(f"分类组合 {len(combos)} 个，并发 {workers}，UA 指纹池 {len(UA_POOL)} 个")
    with ThreadPoolExecutor(max_workers=workers) as ex:
        # 确定性分配：组合序号 → UA_POOL[i % len]（同一分类每轮同一 UA，
        # 配额池身份稳定 —— 随机轮换会让配额池身份散掉，见 UA_POOL 注释）
        def _one(t):
            i, c = t
            u = UA_POOL[i % len(UA_POOL)]
            return fetch_group(c, ua=u, ua_i=i % len(UA_POOL))
        groups = list(ex.map(_one, enumerate(combos)))
    n = sum(len(g["entries"]) for g in groups)
    # 空栏目自检：上游说有数据（系列数 > 0）而我们一条都没取到 ⇒ 一定是容器/参数没对上，
    # 不能当「这个栏目本来就没内容」放过去（2026-09-23：全网·港澳台国际专区就是这么丢的）。
    empty = [f"attr={g['tariffAttr']}/t1={g['type1']}/t2={g['type2']}"
             for g in groups if (g.get("series") or []) and not g.get("entries")]
    if empty:
        log(f"  ⚠️ 有系列却零条目的栏目：{empty}")
    total_short = sum(g.get("short") or 0 for g in groups)
    log(f"抓取完成：{n} 条 / {time.time() - t0:.0f}s"
        + (f"；⚠️ 声明对账缺 {total_short} 条（看上面 ⚠️ 行）" if total_short else
           "；声明对账 0 缺口"))
    return {"province": PROV, "provinceName": "河北",
            "fetchedAt": time.strftime("%Y-%m-%d %H:%M:%S"),
            "endpoint": ROOT + "nrtariff/new/Tariff/getTariffListInfo",
            "short": total_short, "groups": groups}


def index_rows(o):
    rows, seen = {}, {}
    for g in (o or {}).get("groups") or []:
        # ★ 口径必须与 rows_of() 逐字一致（原来是 ZFLX.get(type2) 硬查，只有移动对得上）：
        #   联通的一级分类号 1..5 与移动 ZFLX 同名同义，但「99 停售套餐」移动没有；
        #   广电的 type2 是 GZ_TC_5G 这种代码，ZFLX 里根本没有 ⇒ 变更报告里种类名会显示 "?"。
        #   以采集侧给的中文名为准，没有再退回 ZFLX。
        ty = g.get("type2Name") or ZFLX.get(str(g.get("type2")), "?")
        for e in g.get("entries") or []:
            nm = str(e.get("name") or e.get("tariffName") or "").strip()
            base = f"{g.get('type2')}|{g.get('tariffAttr')}|{nm}"
            seen[base] = seen.get(base, 0) + 1
            k = base if seen[base] == 1 else f"{base}#{seen[base]}"
            row = {f: str(e.get(f) or "").replace("\n", " ").strip() for f in KEY_FIELDS}
            row.update({"_ty": ty, "_attr": g.get("tariffAttr"), "_name": nm,
                        "_tname": str(e.get("tariffName") or "").strip(),
                        "_reportNo": str(e.get("reportNo") or "").strip(),
                        # 违约责任原文（2026-10-08）：不在 KEY_FIELDS（进 diff 会首轮
                        # 全量 changed），但指纹审计（rsp_audit）需要逐条原文。
                        "_rsp": str(e.get("responsibility") or "").strip()})
            rows[k] = row
    return rows


def diff_rows(old, new):
    ok, nk = set(old), set(new)
    added, removed = sorted(nk - ok), sorted(ok - nk)
    changed = []
    for k in sorted(ok & nk):
        d = {f: (old[k].get(f, ""), new[k].get(f, ""))
             for f in KEY_FIELDS if old[k].get(f, "") != new[k].get(f, "")}
        if d:
            changed.append((k, d))
    return added, removed, changed


# —— 违约责任指纹审计（2026-10-08）——
# 🔴 动机：responsibility 不在 KEY_FIELDS（进 diff 会首轮全量 changed，另案评估
#    过被否），运营商**上调违约金标准**（优惠金额倍数 2 倍→3 倍这类真金白银）
#    目前不产生任何变更报告 —— 这正是用户最该被通知的变化。
# 指纹口径：文本里的全部数字（金额/倍数/月数）排序成元组。
#   文字微调（改措辞/调语序）不触发；数字变了必触发 —— 违约责任条款里的
#   数字几乎都是钱和期限，没有无关数字（实测抽样确认）。
#   纯否定句（无需承担违约责任）无数字 → 空指纹，与「无条款」同值 —— 刻意的：
#   本审计只回答「违约金标准有没有变」，有没有条款由页面徽章回答。
RSP_SIG_RE = re.compile(r"\d+(?:\.\d+)?")


def rsp_sig(txt):
    return tuple(sorted(RSP_SIG_RE.findall(txt or "")))


def rsp_audit(oidx, idx):
    """逐条对比新旧快照的违约责任数字指纹。

    返回 [(key, name, old_txt, new_txt)]（指纹有差的条，按键排序）。
    只比对两轮都存在的条 —— 新增/下线由主报告负责，这里不重复。
    """
    out = []
    for k in sorted(set(oidx) & set(idx)):
        ot, nt = oidx[k].get("_rsp") or "", idx[k].get("_rsp") or ""
        if ot == nt or rsp_sig(ot) == rsp_sig(nt):
            continue
        out.append((k, idx[k].get("_name") or idx[k].get("_tname") or k, ot, nt))
    return out


# 字段变更样本「整行对照」的展示字段顺序 —— 页面照这个顺序铺行，
# 把用户最关心的月费/流量/通话放前面，权益说明这类长文本垫底。
DIFF_SHOW_FIELDS = ("fees", "data", "dataUnit", "call", "brandwidth",
                    "applicablePeople", "channel", "validPeriod",
                    "onlineDay", "offineDay", "extraFees", "otherContent")
DIFF_VAL_MAX = 48         # 单个值截断长度（history.json 是长期提交的文件）


def diff_row_payload(o_row, n_row, changed_fields):
    """一条变更资费的**整行**旧→新对照（页面全字段 diff 卡的数据）。

    返回 [字段中文名, 旧值, 新值, 是否变更(0/1)] 的数组：
    - 只收「至少一侧非空」的字段 —— 两边都空展示出来只是噪音；
    - 值截到 DIFF_VAL_MAX 字；换行压成空格（页面 diff 行是单行布局）；
    - 变更字段打 1 标，页面据此高亮 —— 未变的字段也要显示（用户要看
      「这个套餐长什么样」），但视觉上退后一步。
    """
    rows = []
    for f in DIFF_SHOW_FIELDS:
        ov = str(o_row.get(f, "") or "").replace("\n", " ").strip()
        nv = str(n_row.get(f, "") or "").replace("\n", " ").strip()
        if not ov and not nv:
            continue
        rows.append([FIELD_CN.get(f, f), ov[:DIFF_VAL_MAX], nv[:DIFF_VAL_MAX],
                     1 if f in changed_fields else 0])
    return rows


def build_smp(idx, oidx, added, removed, changed):
    """构造 history.json 的 smp 样本数组 —— 页面「变化历史」的明细层。

    独立成函数而不写在 write_report 里：backfill_history 回填历史时要从
    快照重算**一模一样**的样本结构（见那边 enrich 逻辑），两处各写一份
    迟早漂移 —— 页面上「运行时记录」和「回填记录」长得不一样就是症状。
    """
    _smp = []
    for k in added[:6]:
        r = idx[k]
        _smp.append({"n": (r.get("_name") or r.get("_tname") or "")[:60],
                     "ty": r.get("_ty") or "", "k": "a"})
    for k in removed[:4]:
        r = oidx[k]
        _smp.append({"n": (r.get("_name") or r.get("_tname") or "")[:60],
                     "ty": r.get("_ty") or "", "k": "r"})
    # 字段变更样本：上限与 changes/*.md 的明细段一致（120 条）——
    #   实际分布里单轮最多 116 条，页面先铺 6 张、其余折叠，多存不撑爆。
    for k, dd in changed[:120]:
        r = idx[k]
        _smp.append({"n": (r.get("_name") or r.get("_tname") or "")[:60],
                     "ty": r.get("_ty") or "", "k": "c",
                     "f": list(dd.keys())[:4],
                     "rows": diff_row_payload(oidx[k], idx[k], dd)})
    return _smp


def brief(row):
    fee = row.get("fees") or "—"
    gb = ((row.get("data") or "") + (row.get("dataUnit") or "")).strip() or "—"
    ap = row.get("applicablePeople") or "—"
    if len(ap) > 70:
        ap = ap[:70] + "…"   # R2（2026-10-04）：硬切无提示，读的人不知道内容被截了
    return f"月费 {fee} 元 · 流量 {gb} · 通话 {row.get('call') or '—'} 分 · {ap}"


def load_history():
    """读 history.json。缺失/损坏一律回空表 —— 它是展示用的旁路数据，
    **不该**因为一份坏文件把整轮巡检或页面构建打断。"""
    try:
        with open(HIST_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and isinstance(d.get("items"), list):
            return d
    except Exception:
        pass
    return {"schema": 1, "items": []}


def _code_of_net(net):
    """报告里的中文网名 → 网 code（NETS_META 的显示名是后缀匹配：
    「河北移动」「河北联通」「中国广电」「河北电信」都对得上）。"""
    for c, cn, _ in NETS_META:
        if net == cn or net.endswith(cn):
            return c
    return ""


def hist_append(rec):
    """往 history.json 写一条「某网某轮巡检」的变更记录 —— 同一天同一网只留最新一条。

    ★ 去重键是 **(日期, 网)**，不是 (抓取时刻, 网)。一天里跑两轮是常态
      （定时巡检 + 手动 workflow_dispatch / CI 重试），而两轮的比对基线都是
      「上一个不同日期的快照」，所以后一轮的数字**覆盖**前一轮，不该各记一条。
      按时刻去重会让时间线上同一天冒出两组互相矛盾的数字
      （2026-09-23 实测：上午移动 3861 · 新增 0，下午 3862 · 新增 1 ——
       页面顶部「本次巡检」显示的是后者，历史页里两条并存，看着像数据错乱）。
    ★ 覆盖时**原位替换**，不删掉再追加：items 按时间顺序读，当天那条本就该待在
      自己日期的位置上。
    ★ 只保留最近 HIST_KEEP 条：这个文件在仓库里、每轮巡检都提交，
      不设上限就会一年年涨上去。
    """
    h = load_history()
    items = list(h["items"])
    key = (rec.get("d"), rec.get("code"))
    for i, x in enumerate(items):
        if (x.get("d"), x.get("code")) == key:
            items[i] = rec
            break
    else:
        items.append(rec)
    h["schema"] = 1
    h["items"] = items[-HIST_KEEP:]
    # indent=1 而不是紧凑：这个文件每天被 CI 提交一次，缩进让 diff 只显示
    # 「新增了哪条记录」；紧凑格式整个文件是一行，diff 里什么都看不出来。
    # 🔴 newline="\n" 必须显式给：Windows 下默认会把 \n 翻译成 \r\n，
    #    于是每次 CI（Linux，写 LF）与本地（Windows，写 CRLF）交替提交时，
    #    整个文件的每一行都显示为「已修改」，真正的变更淹没在行尾噪音里。
    # 🔴 走原子写：这个文件一旦写坏，页面时间线与 CI 的 history 断言会一起红，
    #    而它是**产物不是接口** —— 宁可保持上一版完整内容。
    if G:
        G.write_json(HIST_FILE, h)
    else:
        with open(HIST_FILE, "w", encoding="utf-8", newline="\n") as f:
            json.dump(h, f, ensure_ascii=False, indent=1)
    return h


def write_report(old_o, new_o, added, removed, changed,
                 net="河北移动", fname=None, guard=None):
    """写变更报告。

    ``net`` / ``fname`` 是接第二网时加的：联通那网要写自己的标题，
    报告也不能和移动挤同一个 ``changes/<日期>.md``（会互相覆盖）。

    ``guard`` ＝ ``change_guard.audit_diff()`` 的结果（可为 None）。
    ★ 传进来的 ``added`` / ``removed`` / ``changed`` 已经**是护栏核验后**的集合；
      ``guard`` 只用来补一段「被摘掉了什么、为什么」—— 那段不能省：
      一个数字变小了而报告里不说明为什么变小，下一个看报告的人只会怀疑数据错了。
    """
    d = new_o.get("fetchedAt", "")[:10]
    # R1（2026-10-04）：截断提示里给**具体快照路径** —— 原先只写「见快照」，
    # 读者要自己猜是哪个文件。快照文件名 = 前缀 + 日期 + .json.gz（与 other_nets
    # 里 basename 切片的约定同源）。上一版日期取 old_o 的 fetchedAt（可能缺失）。
    _sp = SNAP_PREFIX.get(_code_of_net(net), "")
    _snap_today = f"cloud/tariff/snapshots/{_sp}{d}.json.gz" if _sp else ""
    _prev8 = (old_o.get("fetchedAt", "") or "")[:10].replace("-", "")
    _snap_prev = f"cloud/tariff/snapshots/{_sp}{_prev8}.json.gz" if (_sp and _prev8) else ""
    idx, oidx = index_rows(new_o), index_rows(old_o)
    L = [f"# {net}资费变更报告 · {d}", "",
         f"- 本次抓取：{new_o.get('fetchedAt')}",
         f"- 上次抓取：{old_o.get('fetchedAt', '（无）')}",
         f"- 条目数：{len(oidx)} → **{len(idx)}**",
         f"- 新增 **{len(added)}** · 下线 **{len(removed)}** · 字段变更 **{len(changed)}**", ""]

    # ── 护栏段落：把「被抑制的假变化」摊开 ─────────────────────────────
    # 这一段的定位是**审计凭证**：报告头部的三个数字是「可信变化」，
    # 而这里回答「那剩下的去哪了」。没有它，护栏本身就成了一个黑箱 ——
    # 而黑箱化的护栏比没有护栏更危险（真变化被吃掉时无人能察觉）。
    if guard:
        gsec = []
        rel = guard.get("relocated") or []
        if rel:
            gsec += [f"### 身份漂移 {len(rel)} 条（不计入新增/下线）", "",
                     "同一条资费换了栏目/板块 —— 身份键里含栏目名，不加这一步会被记成"
                     "「下线一条 + 新增一条」。", ""]
            for a, b in rel[:20]:
                gsec.append(f"- **{oidx.get(a, {}).get('_name') or idx.get(b, {}).get('_name') or a}**"
                            f"　`{a}` → `{b}`")
            if len(rel) > 20:
                gsec.append(f"- …（其余 {len(rel) - 20} 条见快照）")
            gsec.append("")
        sm = guard.get("state_moved") or []
        if sm:
            downs = [(a, b) for a, b, d in sm if d == "to_stopped"]
            ups = [(a, b) for a, b, d in sm if d == "from_stopped"]
            gsec += [f"### 状态桶迁移 {len(sm)} 条（**已计入**上面的下线/新增，不重复记）", ""]
            if downs:
                gsec.append(f"- 转入停售目录 **{len(downs)}** 条 → 计为下架")
            if ups:
                gsec.append(f"- 从停售目录转回在售 **{len(ups)}** 条 → 计为新增")
            gsec += ["", "> 上游把资费在「在售目录」与「停售目录（一级分类 99）」之间挪动。"
                         "同一条被挪动时旧键下线、新键上线，**只能算一次** —— "
                         "否则就是那个「新增 120 / 下线 123」的老毛病。", ""]
            gsec.append("> ⚠️ 这一类**不按下线日期复核**：联通停售桶的 endDate 实测几乎都未到期"
                        "（本轮 110 条里有 4 条写着 2029-12-31），桶归属才是它的下架证据。")
            gsec.append("")
        fr = guard.get("fake_removed") or []
        if fr:
            gsec += [f"### 假下架 {len(fr)} 条（下线日期尚未到期，判为漏采）", ""]
            for k in fr[:20]:
                r = oidx.get(k, {})
                gsec.append(f"- **{r.get('_name') or r.get('_tname')}**"
                            f"　下线日 `{r.get('offineDay') or '—'}`")
            gsec += ["", "> 上游按随机子集返回时，「本轮没采到」与「业务下架」长得一模一样；"
                         "下线日期是唯一能区分二者的字段。", ""]
        rs = guard.get("restored") or []
        if rs:
            gsec += [f"### 补录 {len(rs)} 条（上线日早于上一轮基线，不是新上架）", ""]
            for k in rs[:20]:
                r = idx.get(k, {})
                gsec.append(f"- **{r.get('_name') or r.get('_tname')}**"
                            f"　上线日 `{r.get('onlineDay') or '—'}`")
            gsec += ["", "> 上一轮限流/降级漏采 ⇒ 本轮补回。**不计新增、不进推送**。", ""]
        for n in (guard.get("notes") or []):
            L.append(f"> 🛡 {n}")
        if guard.get("notes"):
            L.append("")
        if gsec:
            L += ["## 🛡 护栏核验（以下**不计入**上面的三个数字）", ""] + gsec

    # ── 违约责任指纹审计：不在变更计数里，只摊开事实 ─────────────
    # 只对移动做：responsibility 字段目前只有移动上游给（其余三网恒空，
    # 指纹恒等比对是纯浪费）。放报告尾部而不是头部：它是「额外的眼睛」，
    # 别把主变更列表挤到读者要滚动才能看到。
    if _code_of_net(net) == "move":
        ra = rsp_audit(oidx, idx)
        if ra:
            L += [f"## ⚖️ 违约责任指纹变化（{len(ra)} 条，不计入变更计数）", "",
                  "> responsibility 不在 diff 字段里（进 diff 会首轮全量 changed）；"
                  "这里独立对比数字指纹 —— 文字微调不报，违约金/合约期等**数字标准**变了必报。", ""]
            for k, nm, ot, nt in ra[:20]:
                L.append(f"- **{nm}**　指纹 `{','.join(rsp_sig(ot)) or '（无）'}` → `{','.join(rsp_sig(nt)) or '（无）'}`")
                L.append(f"  - 旧：`{ot[:90] or '—'}`")
                L.append(f"  - 新：`{nt[:90] or '—'}`")
            if len(ra) > 20:
                L.append(f"- …（其余 {len(ra) - 20} 条见当日快照 `{_snap_today or 'snapshots/'}`）")
            L.append("")

    if added:
        L += [f"## 新增资费（{len(added)}）", ""]
        for k in added[:120]:
            r = idx[k]
            L.append(f"- **{r['_name'] or r['_tname']}** 〔{r['_ty']}〕 {brief(r)}")
            if r.get("_reportNo"):
                L.append(f"  - 报备编号 `{r['_reportNo']}` · 上线 {r.get('onlineDay') or '—'}"
                         f" ~ 下线 {r.get('offineDay') or '—'}")
        if len(added) > 120:
            L.append(f"- …（其余 {len(added) - 120} 条见当日快照 `{_snap_today or 'snapshots/'}`）")
        L.append("")
    if removed:
        L += [f"## 下线/下架资费（{len(removed)}）", ""]
        for k in removed[:120]:
            r = oidx[k]
            L.append(f"- **{r['_name'] or r['_tname']}** 〔{r['_ty']}〕 {brief(r)}")
        if len(removed) > 120:
            L.append(f"- …（其余 {len(removed) - 120} 条见上一版快照 `{_snap_prev or 'snapshots/'}`）")
        L.append("")
    if changed:
        L += [f"## 关键字段变更（{len(changed)}）", ""]
        for k, dd in changed[:120]:
            r = idx[k]
            L.append(f"- **{r['_name'] or r['_tname']}** 〔{r['_ty']}〕")
            for f, (a, b) in dd.items():
                L.append(f"  - {FIELD_CN.get(f, f)}：`{a[:70] or '—'}` → `{b[:70] or '—'}`")
        if len(changed) > 120:
            L.append(f"- …（其余 {len(changed) - 120} 条见当日快照 `{_snap_today or 'snapshots/'}`）")
        L.append("")
    if not (added or removed or changed):
        L += ["本次未检测到任何变化。", ""]
    txt = "\n".join(L)
    p = os.path.join(CHG, fname or f"{d}.md")
    if G:
        G.atomic_write_text(p, txt, newline="\n")
    else:
        with open(p, "w", encoding="utf-8") as f:
            f.write(txt)
    # ★ 顺手把这一网的变更摘要追加进 history.json（页面时间线用）。
    #   放在 write_report 里、而不是各调用点：移动走 main()、其余三网走 net_round()，
    #   两处**都**经过这里；写在调用点就得分两遍，漏一处 = 时间线里少一网且不报错。
    #   样本构造在 build_smp（与回填共用，字段变更样本带整行旧→新对照）。
    _smp = build_smp(idx, oidx, added, removed, changed)
    rec = {"ts": str(new_o.get("fetchedAt") or "")[:19], "d": d,
           "code": _code_of_net(net), "net": net, "n": len(idx),
           "a": len(added), "r": len(removed), "c": len(changed), "smp": _smp}
    if guard:
        # 护栏数字也记进时间线：只有「本轮 a=0/r=0」而没有任何解释时，
        # 页面上的「本次无变化」会被读成「上游确实没变」——
        # 而它有可能其实是「数据异常已冻结」或「判定为基线回弹」。
        for k, n in (("restored", "gs"), ("fake_removed", "gf"),
                     ("relocated", "gl"), ("state_moved", "gm")):
            if guard.get(k):
                rec[n] = len(guard[k])
        if guard.get("rebound"):
            rec["note"] = "rebound"
    hist_append(rec)
    return p, txt


def write_page(html_body, tag=""):
    """把页面**先写成 ``.new``，校验通过再原子替换** ``docs/index.html``。

    🔴 为什么不能直接盖：这个文件是部署产物，坏掉的表现是**全站白屏**
       （`const NETS=` 那一段语法错了，整页 JS 全废，而标签看着都在）。
       而「写到一半被 kill」「模板改坏」这两件事都不报错、只是留下一个坏文件 ——
       上一步刚刚算好、下一轮才能重来的数据就这么没了。
       先写 ``.new`` 再验，等于给这一步加了一道闸门：
       闸门不过就**保留上一版可用的页面**，明明白白报错，而不是把线上打黑。

    返回 (是否成功, 说明)。
    """
    tmp = HTML_DST + ".new"
    if G:
        G.atomic_write_text(tmp, html_body, newline="\n")
    else:
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            f.write(html_body)
    s = open(tmp, encoding="utf-8").read()
    # 占位符不许残留：漏替换会让 `const HIST=__HIST__` **直接变成语法错误**，
    # 整页功能全废而标签都在 —— CI 里那条同类断言也是照这个写的。
    left = [p for p in PLACEHOLDERS if p in s]
    if left:
        log(f"!! 页面校验不通过（占位符未替换 {left}），保留上一版 {os.path.basename(HTML_DST)}")
        os.remove(tmp)
        return False, f"占位符未替换: {left}"
    if "const NETS=" not in s:
        log("!! 页面校验不通过（找不到 const NETS= 数据容器），保留上一版页面")
        os.remove(tmp)
        return False, "缺少 const NETS="
    if len(s) < 100000:
        # 四网页面实测 2.5 MB 量级；小到十万字节说明构建中途出了事。
        log(f"!! 页面校验不通过（只有 {len(s)} 字节，明显不完整），保留上一版页面")
        os.remove(tmp)
        return False, f"体积过小 {len(s)}"
    os.replace(tmp, HTML_DST)
    log(f"页面已写入 {os.path.relpath(HTML_DST, BASE)}（{len(s)/1024:.0f} KB{tag}）")
    return True, "ok"


def _load_prev2(prefix="hebei_tariff_"):
    """取**上上一轮**的快照（严格早于「上一轮」那份），仅用于基线回弹判定。

    没有就返回 ``(None, None)`` —— 回弹判据会自动退到「计数级」兜底，
    而不是拿一份空快照去比对（空快照会让「本轮整批下线」看起来像回弹，
    把一批真实的删除吃掉）。
    """
    fs = snap_paths(prefix)
    if len(fs) < 2:
        return None, None
    p = fs[-2]
    try:
        with gzip.open(p, "rt", encoding="utf-8") as f:
            return json.load(f), p
    except Exception as e:
        log(f"-- 上上轮快照不可读（{os.path.basename(p)}）：{type(e).__name__}: {e}")
        return None, None


def last_hist(code, day=""):
    """取 history.json 里该网最近的**一条更早的**记录（用于回弹的计数级判据）。

    🔴 必须显式排除 ``d == day``：当天重跑（手动 dispatch / CI 重试）时，
       当天那条记录用的基线和本轮完全相同，拿它当「上一轮」会得出
       a=0/r=0 之类的假证据。同一天里第一次跑时，它本来也不存在。
    """
    items = load_history().get("items") or []
    for x in reversed(items):
        if x.get("code") == code and str(x.get("d") or "") != str(day or ""):
            return x
    return None


def diff_round(code, cn, tag, data, old_o, prev_p, today, fname=None):
    """一轮数据的完整处理：**结构体检 → diff → 护栏核验 → 写报告 → 记 history**。

    移动走 ``main()``、其余三网走 ``net_round()`` —— 但这两条路必须共用本函数。
    各写一份的代价：改一处漏一处时，症状是「某网静默地不再核验假变化」，
    而日志里一切正常、页面照常更新，没人会发现。

    返回 summary dict（供推送、页面提示、CI 汇总使用）：
      ``n`` ``added`` ``removed`` ``changed`` 计数
      ``restored`` ``fake_removed`` ``relocated`` 被护栏摘掉的条数
      ``samples`` 供推送用的样例 · ``batches`` 批量同改提炼句（≤3 句）
      ``report`` 报告路径 · ``note`` 抑制原因 · ``guard`` 原始护栏结果（供报告用）
    """
    prefix = SNAP_PREFIX[code]
    base_day = (old_o or {}).get("fetchedAt", "")[:10]
    idx_old, idx_new = index_rows(old_o), index_rows(data)
    out = {"code": code, "net": cn, "n": len(idx_new), "added": 0, "removed": 0,
           "changed": 0, "restored": 0, "fake_removed": 0, "relocated": 0,
           "state_moved": 0, "samples": [], "batches": [], "report": "",
           "note": "", "guard": None,
           "_added_keys": [], "_removed_keys": [], "_changed_keys": []}

    if not G:
        # 护栏不可用时**照旧出报告**，但把这件事吼出来 ——
        # 静默降级成「没有核验」比没有核验更糟。
        log(f"!! 护栏模块不可用（{_G_ERR}），本轮不做假变化核验")
    else:
        sig_old = G.schema_sig(old_o, KEY_FIELDS)
        sig_new = G.schema_sig(data, KEY_FIELDS)
        if G.REBUILD_ON_SCHEMA and sig_old != sig_new:
            # ④ 结构变更 ⇒ 只重建基线，不通知。
            #   为什么必须这样：我们改采集字段（或上游开始普遍填一个新字段）时，
            #   每条资费都会「多出一个字段有值」⇒ 一次改动炸出上千条「字段变更」，
            #   而它们**没有一条**是业务变化。重建基线是唯一诚实的选择。
            log(f"!! {cn} 字段结构变更：{len(sig_old)} 个字段 → {len(sig_new)} 个字段"
                f"（新增 {sorted(set(sig_new) - set(sig_old))}，"
                f"消失 {sorted(set(sig_old) - set(sig_new))}）—— 只重建基线，不通知")
            out["note"] = "schema"
            if G:
                G.atomic_write_text(
                    os.path.join(CHG, fname or
                                 f"{tag}-{today[:4]}-{today[4:6]}-{today[6:]}.md"),
                    f"# {cn}资费基线重建 · {data.get('fetchedAt', '')[:10]}\n\n"
                    f"- 本轮检测到**字段结构变更**，只重建基线、不出变更报告、不推送\n"
                    f"- 旧字段：{'、'.join(sig_old) or '（无）'}\n"
                    f"- 新字段：{'、'.join(sig_new) or '（无）'}\n"
                    f"- 条目数：{len(idx_old)} → **{len(idx_new)}**\n"
                    f"- 原因：结构一改，每条资费都会「多/少一个字段有值」，"
                    f"逐条报「字段变更」等于一次刷屏上千条，且无一是业务变化。\n",
                    newline="\n")
            hist_append({"ts": str(data.get("fetchedAt") or "")[:19],
                         "d": str(data.get("fetchedAt") or "")[:10],
                         "code": code, "net": cn, "n": len(idx_new),
                         "a": 0, "r": 0, "c": 0, "note": "schema", "smp": []})
            return out

    a, r, c = diff_rows(idx_old, idx_new)
    guard = None
    if G:
        old2, _ = _load_prev2(prefix)
        guard = G.audit_diff(
            a, r, c, idx_old, idx_new,
            today=today,
            base_day=base_day,
            old2_rows=(index_rows(old2) if old2 else None),
            prev_rec=last_hist(code, str(data.get("fetchedAt") or "")[:10]),
            log=log)
        a, r, c = guard["added"], guard["removed"], guard["changed"]
        out.update({"restored": len(guard["restored"]),
                    "fake_removed": len(guard["fake_removed"]),
                    "relocated": len(guard["relocated"]),
                    "state_moved": len(guard["state_moved"])})
        if guard["rebound"]:
            # ③ 基线回弹：本轮不计变化、不推送，**但报告照写**（留审计痕迹）。
            log(f"!! {cn} 判定为基线回弹（{'；'.join(guard['suspected'])}），"
                f"本轮不计变化、不推送")
            out["note"] = "rebound"
            a, r, c = [], [], []

    # ⑥ 采样噪声护栏（2026-10-04 接线，recheck-20261004 #2）：
    #    放在 change_guard 核验**之后** —— 护栏摘掉假下架/补回真条目后，
    #    剩下的才是「真要放行」的变化量，拿它判噪声才不会双重误伤。
    #    命中 ⇒ 与回弹同路径：本轮不计变化、不推送，报告与 history 留痕。
    #    判不出来（模块缺失）就保留 —— 与全仓库「护栏判不出来就不拦」同一条原则。
    if G and NG and not out["note"] and \
            NG.is_sampling_noise(len(a), len(r), len(idx_old)):
        out["note"] = "noise"
        a_orig, r_orig = len(a), len(r)
        a, r, c = [], [], []
        fname2 = fname or f"{tag}-{today[:4]}-{today[4:6]}-{today[6:]}.md"
        rp2 = os.path.join(CHG, fname2)
        txt = (f"# {cn}本轮判定为采样噪声 · {data.get('fetchedAt', '')[:10]}\n\n"
               f"- 变化量达到「整批换人」级别（新增 {a_orig} / 下线 {r_orig}，"
               f"基线 {len(idx_old)} 条）—— 上游疑似按随机子集轮换返回，"
               f"「本轮没采到」与「业务下架」此时长得一模一样\n"
               f"- 按护栏设计**本轮不计变化、不推送**；基线快照照常落库，"
               f"下一轮若恢复正常即自动跟进\n"
               f"- 若连续多轮命中，说明上游在持续轮换子集，需要人工核对采集口径"
               f"（可调 NOISE_RATIO / NOISE_MIN_ABS 环境变量放宽阈值）\n")
        if G:
            G.atomic_write_text(rp2, txt, newline="\n")
        else:
            with open(rp2, "w", encoding="utf-8") as f:
                f.write(txt)
        # history 必须自己记（write_report 没走）：a/r 记 0（本轮确实没记入变化），
        # note=noise 让页面时间线亮「⚠ 采样噪声」徽标 —— 静默抹掉几百条假变化
        # 而时间线上毫无痕迹，等于把「护栏拦截」伪装成「天下太平」。
        hist_append({"ts": str(data.get("fetchedAt") or "")[:19],
                     "d": str(data.get("fetchedAt") or "")[:10],
                     "code": code, "net": cn, "n": len(idx_new),
                     "a": 0, "r": 0, "c": 0, "note": "noise", "smp": []})
        log(f"!! {cn} 判定为采样噪声（新增 {a_orig} / 下线 {r_orig} / 基线 "
            f"{len(idx_old)}），本轮不计变化、不推送")
        out["report"] = rp2
        return out

    rp, _ = write_report(old_o, data, a, r, c, net=cn,
                         fname=fname or f"{tag}-{today[:4]}-{today[4:6]}-{today[6:]}.md",
                         guard=guard)
    out.update({"added": len(a), "removed": len(r), "changed": len(c),
                "report": rp, "guard": guard,
                # 键集合要给调用方（页面标注 ca/ck 用），但不下放给推送 ——
                # 推送只该拿到「几条 + 几个样例」，不是全量键。
                "_added_keys": list(a), "_removed_keys": list(r),
                "_changed_keys": [k for k, _ in c],
                "samples": _samples(a, r, c, idx_new, idx_old),
                # 批量同改提炼句（≤3 句）：在**这一侧**算好、只把句子下放 ——
                # 通知层不该拿到全量 changed 明细（同上「不是全量键」的原则）。
                "batches": (NOTIFY.batch_same_change(c, FIELD_CN) if NOTIFY else [])})
    return out


def _samples(added, removed, changed, idx_new, idx_old, max_n=8):
    """推送用的样例条目（只挑几条，通知不是报告）。"""
    out = []
    for k in list(added)[:max_n]:
        r = idx_new.get(k) or {}
        out.append({"n": (r.get("_name") or r.get("_tname") or "")[:40],
                    "ty": r.get("_ty") or "", "k": "a"})
    for k in list(removed)[:4]:
        r = idx_old.get(k) or {}
        out.append({"n": (r.get("_name") or r.get("_tname") or "")[:40],
                    "ty": r.get("_ty") or "", "k": "r"})
    for k, _ in list(changed)[:4]:
        r = idx_new.get(k) or {}
        out.append({"n": (r.get("_name") or r.get("_tname") or "")[:40],
                    "ty": r.get("_ty") or "", "k": "c"})
    return out


def _degrade(code, cn, n, n_old):
    """⑤ 降级状态机的一层薄封装：读状态 → 判定 → 落盘。返回 (动作, 轮次说明)。"""
    if not G:
        # 护栏不可用：退回「单轮阈值」的老行为，但把这件事说清楚
        return ("hold" if (n_old > 0 and n < n_old * DEGRADE_RATIO) else "ok"), ""
    st = G.read_json(DEGRADE_STATE, {}) or {}
    act, st = G.degrade_step(st, code, n, n_old,
                             stamp=time.strftime("%Y-%m-%d %H:%M:%S"))
    G.write_json(DEGRADE_STATE, st)
    rec = st.get(code) or {}
    if act == "hold":
        return act, (f"第 {rec.get('rounds')}/{DEGRADE_ACCEPT_ROUNDS} 轮"
                     f"（连续 {DEGRADE_ACCEPT_ROUNDS} 轮才接受新数据）")
    if act == "accept":
        return act, f"连续 {DEGRADE_ACCEPT_ROUNDS} 轮偏低，认定源站现状如此，接受并重建基线"
    return act, ""


def _hold(code, cn, tag, data, old_o, prev_p, today, why, note="degraded", fname=None):
    """降级「冻结旧数据」的收尾：写一份说明报告 + 记一条带 note 的 history。

    🔴 为什么不能**静默**保留旧数据：页面看着正常、数据其实是旧的 ——
       这正是「一直冻结旧数据」最危险的地方。所以：
         · 页面照旧渲染上一版（数据不断供）；
         · changes/<日期>.md 里写明「本轮没采到，沿用上一版」；
         · history 里记 ``note``，页面时间线上那一条会显示成「数据异常已冻结」，
           而不是伪装成「本次无变化」。
    """
    day = f"{today[:4]}-{today[4:6]}-{today[6:]}"
    rp = os.path.join(CHG, fname or f"{tag}-{day}.md")
    n_old = sum(len(g["entries"]) for g in (old_o or {}).get("groups") or [])
    txt = (f"# {cn}资费巡检 · {day}\n\n"
           f"- ⚠️ 本轮**未采用**新数据：{why}\n"
           f"- 本轮采到：{data.get('fetchedAt') if data else '（采集失败）'}\n"
           f"- 页面与报告沿用上一版快照（{n_old} 条）\n"
           f"- 原因：数据量/结构异常时直接换基线，会把「本轮没采到」记成"
           f"「一大批资费下架」—— 实测同类项目一次假下架 1613 条（96% 的下线日期仍在未来）。\n")
    if G:
        G.atomic_write_text(rp, txt, newline="\n")
    else:
        with open(rp, "w", encoding="utf-8") as f:
            f.write(txt)
    hist_append({"ts": str((data or {}).get("fetchedAt") or "")[:19], "d": day,
                 "code": code, "net": cn, "n": n_old, "a": 0, "r": 0, "c": 0,
                 "note": note, "smp": []})
    return rp, txt


def archive_page():
    """把查询页 gzip 归档进仓库（``page/index.html.gz``），供本机 view_page.py 取用。

    页面已无公网入口（GitHub 免费版 Pages 只支持公开仓库），要「本机不跑抓取就能看」，
    就得有地方取 —— 这就是那个地方。归档进 git 也顺带成了页面快照存档。

    ★ 直接按字节比对去重，只有资费数据真变了才写新归档。

      能做到「按字节比」的前提曾是：**页面里不含任何运行时刻**。
      2026-10-03 起页面横栏带各网快照的抓取时刻（net_payload 的 ts，分钟级，
      来自快照里的 fetchedAt）—— 它随每次新抓取变化，所以「同日重跑、数据没变」
      也会产生新归档字节。刻意接受：用户要求看到更新时刻；ts 绑定的是数据
      （快照冻结时 ts 停在旧时刻，不会显示骗人的新时间），纯模板重渲染
      （--render-only，NETS 原样沿用）仍然字节稳定、去重照常生效。

      ⚠️ 早先的版本是「用正则把时间戳抹掉再比」，那样有个隐患：正则
      ``\\d{4}-\\d\\d-\\d\\d[ T]\\d\\d:\\d\\d:\\d\\d`` 会连带命中业务字段。
      当前 ``onlineDay``/``offineDay`` 的格式是 ``20030517``（无分隔符）侥幸没被误伤，
      但哪天上游把格式换成 ``2003-05-17 00:00:00``，真实的上下线变更就会被**静默忽略**。
      现在页面只有 ts 一处运行时刻，正则仍没必要。
    """
    if not os.path.exists(HTML_DST):
        return None
    cur = open(HTML_DST, encoding="utf-8").read()
    if os.path.exists(PAGE_GZ):
        try:
            with gzip.open(PAGE_GZ, "rt", encoding="utf-8") as f:
                old = f.read()
            if old == cur:
                log("页面内容与归档一致（数据未变），跳过归档")
                return PAGE_GZ
        except Exception as e:
            log(f"读取旧归档失败，将重新写入：{type(e).__name__}: {e}")
    os.makedirs(PAGE_DIR, exist_ok=True)
    raw = cur.encode("utf-8")
    # mtime=0 同样内容 => 同样字节（与快照一致）
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=9, mtime=0) as f:
        f.write(raw)
    # ★ 原子写：归档是「本机不跑抓取就能看」的唯一来源，写坏等于这一版页面丢了。
    if G:
        G.atomic_write_bytes(PAGE_GZ, buf.getvalue())
    else:
        with open(PAGE_GZ, "wb") as f:
            f.write(buf.getvalue())
    log(f"页面已归档 {os.path.relpath(PAGE_GZ, BASE)}"
        f"（{os.path.getsize(PAGE_GZ) / 1024:.0f} KB，原始 {len(raw) / 1048576:.2f} MB）")
    return PAGE_GZ


def data_day(o, fallback=""):
    """取页面顶部那个「数据基线日期」（__DATE__）。

    🔴 为什么值得单独一个函数：页面的**全部相对天数**与**上架/下线时间筛选**都以它为基准。
    它一旦不是合法的 YYYY-MM-DD，页面侧 BASE 解析失败 → ago/left 变 NaN →
    `NaN<0 || NaN>7` 恒为 false → 「7 天内上架」会**静默返回全部条目**。
    不报错、看着还正常，所以必须在源头拦下并回退到一个稳定值。

    fallback 必须是**稳定**的（快照日/页面已有日期），不能用 time.strftime("today")：
    页面里一旦带上会变的日期，归档的逐字节去重就废了。
    """
    s = str((o or {}).get("fetchedAt") or "")[:10]
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        try:
            datetime.date(*(int(g) for g in m.groups()))
            return s
        except ValueError:
            pass
    log(f"!! 数据基线日期不可解析：{s!r} —— 回退到 {fallback or '（空）'}。"
        f"页面会把时间筛选置为 fail-closed，请尽快检查抓取逻辑。")
    return fallback


# —— 四网骨架 ——
# code: (简称, 全称)。顺序即页面导航条顺序。
# ★★ 以下 8 个名字**全部保留**，但已改成由「四网注册表」派生 —— 不再是第二份真相。
#    外部有 4 个脚本在读它们（rebuild_offline.py 解包 NET_RUN 三元组、
#    probes/check_area_scope.py 与 probe_scope_state.py 读 SNAP_PREFIX、
#    selftest_pipeline.py 读 NET_SNAP），删掉任何一个都是**静默断链**。
#    要改「某网是什么」请去改上面的 NetSource 子类，**别在这里加一行** ——
#    那正是本次模块化要消灭的东西（同一网的属性散在多处，漏一处不报错）。
NETS_META = tuple((c, NETS[c].sh, NETS[c].vendor) for c in _PAGE_ORDER)
SRC_OF = {c: NETS[c].src for c in _PAGE_ORDER}
# 技术溯源（接口域名 / 路径）：**只写进 docs 与变更报告**，不进页面 ——
# 页面那行「来源」是给用户看的，塞接口主机名属于噪音（2026-10-02 清理）。
SRC_TECH_OF = {c: NETS[c].src_tech for c in _PAGE_ORDER}
# 每日巡检里**由脚本直连就能采到**的那几家（有 src / base / rows 的）。
# 电信也在里面 —— 但它和另两家不同：它需要真实浏览器，是**机会性采集**
# （采到就正常入库；采不到自动退回下面的 NET_SNAP 快照渲染，绝不拖垮其它网）。
NET_LIVE = tuple(c for c in _RUN_ORDER if NETS[c].live)
# 「采不到时的渲染兜底」名单 —— 目前只有电信。
#
# 2026-09-22 修正：此前这里写的是「电信在云端采不到，只能快照直渲」，
# 那是**推断**（"Runner 上没浏览器"）而不是实测。当天在 ubuntu-latest 上起了
# Xvfb + 有头 Chrome 实测：挑战自动通过、`navigator.webdriver=false`、
# 884 条 5 个分类逐项采全 ⇒ **云端本来就采得到**，缺的只是那一步 xvfb 启动。
#
# 现在的语义是「兜底」而不是「唯一通路」：本轮没拿到采集产物（CI 里那步失败、
# 或本机没有 .ct_raw.json）就用仓库里最新那份快照渲染。这样即使哪天瑞数改规则
# 或 runner 镜像没了 Chrome，页面也**不会少一网**，只是数据停在上一版 ——
# 而且基线日期取自快照自身，陈旧是**看得见**的，不会假装今天更新过。
NET_SNAP = tuple(c for c in _RUN_ORDER if NETS[c].fallback == "latest")
# 每网一份独立快照，文件名前缀区分 —— 共用一套快照会让两网互相覆盖
# （load_prev 按文件名排序取「最近一份」，混在一起就会拿联通昨天的当移动今天的基准）。
SNAP_PREFIX = {c: NETS[c].snap_prefix for c in _RUN_ORDER}
# 「移动之外」各网的轮次配置：code → (适配器模块名, 报告/摘要里的中文名, 报告文件名前缀)。
# 三处必须**成对**出现（模块、显示名、报告文件名），散在 main() 里各写一遍迟早漏一处。
NET_RUN = {c: (NETS[c].mod, NETS[c].cn, NETS[c].tag)
           for c in _RUN_ORDER if NETS[c].mod}
# 支持「连下架资费一起采」的网 —— 适配器 fetch_all 接受 include_stopped。
# 需求：「各运营商下架的资费也要收集全」。移动**不在**此列：实测它的 isPublic=0
# 虽能列出分类，但明细接口恒返回 0 条，本网拿不到下架数据（见 state_of 注释）。
NET_STOPPED = {c for c in _RUN_ORDER if NETS[c].stopped}
# ★「适配器是**纯本地转换**」的网 —— 它的 fetch_all() 不发网络请求，
#   读的是浏览器采集产物（电信读 .ct_raw.json）。这类网**不该进本地缓存**：
#   缓存只带来一种风险 —— 采集产物更新了而缓存还是旧的，
#   本地重建出来的页面看不出这一点，且没有任何提示（2026-09-23 实测踩到：
#   .telecom_cache.json 停在 09-22，重跑采集也不会被用上）。
#   直读适配器是毫秒级往返，缓存它没有任何收益。
NET_NOCACHE = {c for c in _RUN_ORDER if NETS[c].nocache}
# 🔴 2026-10-04 复查修：这里曾有全局变量 UP_N（注释称「由 build_html 回填、
#   供 __N__ 占位符」）—— 但 __N__ 在 build_html 里直接用局部 total 替换，
#   UP_N 写了从没有任何一处读（全仓 grep 仅 3 处且全在本文件）。
#   死代码留着会误导人以为「条数另有全局出口」，删。


# 页面里的「查看变更明细」链接指向仓库里的 changes/<日期>.md（网页版可直接看）。
# 与 view_page.py 的 DEFAULT_REPO 同值 —— 两个脚本各有独立入口，不互相 import。
REPO = "starrry365/hebei-tariff-monitor"


def repo_rel(path):
    """把路径换算成「相对**仓库根**」的形式 —— GitHub 链接必须以仓库根做基准。

    🔴 别写成 os.path.relpath(path, BASE)：BASE 是**模块目录**（cloud/tariff），
      那样算出来是 "changes/2026-09-23.md"，少了 cloud/tariff/ 这一层前缀，
      生成的链接指向仓库里不存在的路径、点开就是 GitHub 404
      （2026-09-23 用户报障「查看变更明细 → 也不同」）。

    这里从 BASE 逐级往上找 .git 来定位仓库根：模块将来换到别的子目录也不用改。
    万一找不到 .git（比如脚本被单独拷出来跑），退化成相对 BASE —— 至少不会崩。
    """
    d = BASE
    for _ in range(6):
        if os.path.isdir(os.path.join(d, ".git")):
            return os.path.relpath(path, d).replace(os.sep, "/")
        up = os.path.dirname(d)
        if up == d:
            break
        d = up
    return os.path.relpath(path, BASE).replace(os.sep, "/")

# 页面 gz 体积预警线：单网(3878 条) 约 245 KB，四网全接入会到 1 MB 上下。
# 超了就只是**提醒**（不改行为）—— 该考虑按网拆分/按需加载，而不是继续往单文件里塞。
GZ_WARN = 900 * 1024


def net_payload(payloads):
    """把各网的 rows 装进四网容器。

    ``payloads``：``{网code: {"rows": [...], "base": "...", "ts": "...", "src": "..."}}``。
    没给的网自动落成空壳 —— 骨架阶段那两家就是这么留白的。

    ★ 结构刻意做成**对称**的（每网都有 sh/nm/src/base/rows），而不是
      「移动特殊、另两家另放一个数组」—— 后者每加一处逻辑都要分叉一次，迟早漏一边。
    ★ 每网自带 base：相对天数与时间筛选都以**本网**基线为准。各网的抓取时点
      不可能总在同一天，共用一个全局基线会让后接入的那几家整体算错天数。
    ★ ts 是本网快照的抓取时刻（分钟级，取自 fetchedAt）—— 只给「更新于」显示用；
      base 保持纯日期，相对天数/日期解析都依赖它，混进时刻会把那些解析全弄脆。
      ts 是**数据自己的属性**（存在快照里）：数据被降级冻结时它跟着停在旧时刻，
      不会显示一个骗人的新时间。
    """
    out = {}
    for code, sh, nm in NETS_META:
        p = payloads.get(code) or {}
        out[code] = {"sh": sh, "nm": nm,
                     "src": p.get("src") or "",
                     "base": p.get("base") or "",
                     "ts": p.get("ts") or "",
                     # ★ 这里**曾有**一个 allProvince 声明（「本网数据不分城市」），
                     #   页面拿它决定要不要出地市那一层。2026-09-24 删掉：
                     #   联通那网的声明是**错的**（它按城市分数据），而页面信声明、
                     #   不信数据 ⇒ 一个错的声明就能把整个维度藏掉，且毫无提示。
                     #   现在页面按「本网有没有 d.cty」自己判（数据驱动，见 renderDims）。
                     #   教训：**声明与现实脱节时不会有任何报警**，能不用就别用。
                     "rows": p.get("rows") or []}
    return out


def _mark_changes(rows, diff):
    """给页面行打「本次新增 / 关键字段变更」标，并做条数自检。

    标注**错行比不标更坏** —— 用户会据此认定某条资费变了。所以条数对不上就整批撤掉，
    退回「没有标注」，而不是留一批看着像真的、其实指错行的标注。
    """
    if not diff:
        return rows
    want = (len(diff["added"]), len(diff["changed"]))
    got = (sum(1 for r in rows if r.get("ca")), sum(1 for r in rows if r.get("ck")))
    if got != want:
        log(f"!! 变更标注条数对不上（新增 {got[0]}/{want[0]} · 字段变更 {got[1]}/{want[1]}），"
            f"本次不加标注 —— 宁可没有，也不能标错行")
        for r in rows:
            r.pop("ca", None)
            r.pop("ck", None)
    return rows


# ── 流量「数值 + 单位」与月费的归一（构建期，四网共用）──────────────────────
# ★ 目的：让**行数据**里的 `du` 只可能是 ``GB`` / ``MB`` / ``TB`` / ``''``（空＝无流量），
#   `f` 只可能是数字串或空。这样「流量」筛选、「每元流量」排序、CSV 导出三处口径
#   必然一致 —— 判据只此一份，页面只读不算（与 cat / chx / cty 同一条原则）。
# ★ 为什么必须做：上游写法不统一，不归一会产生两类**静默**后果：
#     ① 真缩写认不出：联通写 ``M`` / ``T``（``100M`` 就是 100MB）⇒ 归一前 gb() 返回
#        None ⇒ 该条在「流量」列显示「—」、在「每元流量」排序里**凭空消失**，
#        看着像「上游没填流量」。实测 4 条（100/200/500M + 1T）。
#     ② 占位符与脏值混进单位列：``0`` / ``0GB`` / ``不涉及`` / ``无`` / ``M/B`` ⇒
#        体检就没法用「单位白名单」兜住取值域，上游新增一个单位也没人发现。
# 🔴 归一只在**单位认不出**或**数值为 0** 时动手，绝不碰正常数据：
#    ``d='0' du='GB'``（四网合计 9556 条）是上游表达「本套餐不含流量」的标准写法，
#    gb() 算得 0.0、页面显示「—」、体检本来就过 —— 归一它属于无事生非。
UNIT_ALIAS = {"M": "MB", "MB": "MB", "M/B": "MB",     # 联通写 M；M/B 是脏值
              "G": "GB", "GB": "GB", "GB起": "GB",     # 「GB起」＝至少 GB 档
              "T": "TB", "TB": "TB"}
FEE_NONE = frozenset(("无", "不涉及", "没有", "否", "-", "－", "/", "—"))


def du_norm(data, unit):
    """``(data, dataUnit)`` → ``(数值, 单位)``；单位只可能是 ``GB`` / ``MB`` / ``TB`` / ``''``。

    返回 ``('', '')`` 表示「本套餐不含流量」—— 此时 ``gb()`` 返回 None，页面显示「—」。
    """
    u = str(unit or "").strip().upper()
    d = str(data if data is not None else "").strip()
    if not d:
        return "", ""
    canon = UNIT_ALIAS.get(u)
    if canon:
        return d, canon
    # 单位认不出（占位符 / 脏值 / 空）：只有**数值确实是 0** 时才当「无流量」收起。
    # 数值非 0 又认不出单位 ⇒ 原样留着，让体检的「单位白名单」把它报出来
    #（上游新增单位必须人工过目，这里不能默默吞掉）。
    try:
        if float(d) == 0:
            return "", ""
    except ValueError:
        pass
    return d, u


def fee_norm(v):
    """月费字段归一：上游把「本套餐不收月费」写成 ``无`` / ``不涉及`` ⇒ 归一成空。

    ★ 页面 ``num()`` 对 ``无`` 与空都返回 null（``parseFloat('无')`` 是 NaN），
      所以这里**不改变任何显示与排序**，只是让行数据的取值域干净、
      体检能用「数字串或空」这一条把住。
    """
    s = str(v if v is not None else "").strip()
    return "" if s in FEE_NONE else s


def state_of(code, e, g, base_day):
    """该条目是否「已下架」。

    ★ 只能用**采集侧已有的信号**，不能自己发明判据 —— 四网的「下架」根本不是同一回事：
      · 联通：一级分类 ``99``「停售套餐」。🔴 实测那批 ``endDate`` **一条都没过期**，
        所以**不能靠日期判**（初版注释写的「99.87% 已过期」是当时的样本，现已不成立）——
        它被归到 99 类这件事本身就是唯一下架证据。
      · 广电：服务端状态位 ``stateFlag``（``1`` 在售、``0`` 下架）
      · 电信：该网**没有**独立状态位，只能看下线日是否早于基线日
      · 移动：``isPublic='0'`` 的分类能列出来，但明细接口恒返回 0 条 ⇒ **本网拿不到**
    """
    # 三网各自的下架信号已收进各自的 NetSource 子类（原来这里是三处 ``if code ==``
    # 分叉 —— 加一网就得在此再插一段，而漏插的症状是「该网的下架条目被当成在售」：
    # 页面不报错，只是多出一批本该收起来的数据）。
    ns = NETS.get(code)
    return ns.stopped_of(e, g, base_day) if ns else False


def classify_entry(raw_l1, e, code):
    """条目的分类归档：返回 ``(cat_src, sub, raw_l2)``。

    从 rows_of 里提出的具名函数（recheck-20261004 #11）—— 原先这段
    「停售还原 → 三分支取档 → 联通细分规整」约 40 行嵌在双层数据循环里，
    下次有人改 rows_of 很容易误伤它（它有自己的对账判据：audit_data 的
    oracle 按这里的语义重算）。提出来的额外收益：可以**单独**构造
    ``{"type3Name": ...}`` 做单元验证，不用拼一整个 groups 对象。

    ══ 联通：把「停售套餐(99)」还原成真实分类 ════════════════════
    🔴 实测（2026-09-24，全量 8041 条）：联通把**停售**这件事编码成了一级
      栏目 99「停售套餐」，而那批条目的**真实分类写在二级栏目里** ——
      二级的取值域 {套餐, 加装包, 营销活动, 港澳台/国际资费, 标准资费}
      恰好就是一级栏目那 5 个分类（二级码 1/2/3/4/5 与一级码同号，可自证）。
      照字面把它当分类的后果是**静默错归类 3177 条**（= 联通全部已下架条目）：
      其中 1220 条其实是加装包、581 条标准资费、303 条营销活动、
      42 条港澳台/国际，却全被归成「套餐」；用户按「加装包」筛时
      这 1220 条一个都不会出现，而页面上没有任何异常。
      ★ 「停售」这个语义**已经由「已下架」页签表达**（构建期 st，
        联通判据 = type2 == 99，与这里逐字同源），不必也不该再占一个分类。
      ⇒ 还原规则：停售桶取二级栏目当分类、细分留空（它的二级被分类占用了，
        本就没有更细的信息 —— 留空是诚实的，编一个出来才是错的）。

    ══ 联通细分规整（2026-10-03 重设计）═════════════════════════
    三条规则（只动联通，映射表见 UC_TY_NORM 处注释）：
      ① 与大类同名 → 留空：「标准资费」的二级还是「标准资费」，
        2481 条写两遍同样的词没有信息量，细分下拉也少一个假档；
      ② 港澳台前缀剥离：「国际/港澳台加装包」→「加装包」等，
        大类已表达归属，细分全网取值域规整成两两不重名；
      ③ 「其他」→「其他加装」：避免与「未映射兜底大类」同名混淆。
    停售条目不在此列：上游只有「原一级」这一层（见上），细分留空是诚实的；
    页面在「已下架」页签把细分维度整体停用（dimOff.ty，见模板 condOf）。
    """
    raw_l2 = str(e.get("type3Name") or "").strip()
    if raw_l1 == STOPPED_L1:
        cat_src, sub = (raw_l2 or raw_l1), ""
    elif raw_l2:
        # 上游真有二级栏目（联通在售）⇒ 细分就用它，这才是有信息量的两级。
        cat_src, sub = raw_l1, raw_l2
    else:
        # 本网上游**没有**二级栏目（移动 / 电信 / 广电：条目里连 type3Name
        # 这个键都不存在）⇒ 细分退回一级栏目名，与改动前逐字一致。
        # 🔴 别把「没有二级」当成「二级为空」：那会让这三网的「细分」下拉
        #    整层变成只有一个空档 —— 一个看着还在、实则筛不出东西的控件。
        cat_src, sub = raw_l1, raw_l1
    if code == "unicom":
        if sub == cat_src:
            sub = ""
        sub = UC_TY_NORM.get(sub, sub)
    return cat_src, sub, raw_l2


def rows_of(o, diff=None, code=""):
    """把**某一家**的数据源对象构造成页面行。

    移动与联通在这一层是同构的：联通采集时就把字段名映射成了移动那套
    （feesStandard→fees、startDate→onlineDay…，见 probes/he_unicom_tariff.py
    的 FIELD_MAP），所以两网共用这一个函数，页面无需为任何一家分叉。

    ``code``：网代码。只用于地域归属（``sc``）与下架判定（``st``）——
    这两件事四网判据完全不同，必须知道是哪一家。留空时退化为「不做地域过滤、
    不标下架」，这样旧的调用方（若有）不会被改坏。

    ``diff``（可选）＝ ``{"added": set(键), "changed": set(键)}``，来自 diff_rows。
    给了就给命中的行打 ``ca`` / ``ck`` 标，页面据此显示「新增 / 变更」徽章，
    并支持「只看本次变更」筛选。没给（如 --render-only）时页面只是没有标注。
    """
    def gb(v, unit):
        try:
            f = float(str(v).strip())
        except Exception:
            return None
        u = str(unit or "").upper()
        if u.startswith("MB"):
            return f / 1024.0
        if u.startswith("GB"):
            return f
        if u.startswith("TB"):
            return f * 1024.0
        return None

    base_day = data_day(o)
    # 板块是否该落盘：本网该字段真有两个取值才算（见 ATTR_CN 的注释）。
    _attrs = {str(g.get("tariffAttr") or "").strip() for g in o["groups"]}
    sect_on = len(_attrs & set(ATTR_CN)) >= 2
    rows, seen, dropped = [], {}, 0
    for g in o["groups"]:
        # 联通的一级分类号（1..5）与移动 ZFLX 的 1..5 语义一致，直接复用；
        # 采集侧若给了 type2Name 就以它为准（联通的「99 停售套餐」是移动没有的类）。
        raw_l1 = str(g.get("type2Name") or ZFLX.get(str(g.get("type2")), "?") or "").strip()
        attr = g.get("tariffAttr")
        for e in g["entries"]:
            # 分类归档（停售还原 / 三分支取档 / 联通细分规整）已提具名函数
            # classify_entry —— 判据说明见该函数 docstring，此处不再重复。
            cat_src, sub, raw_l2 = classify_entry(raw_l1, e, code)
            sc, cty = where_of(code, e) if code else ("hb", [])
            # ★ 需求：只要「河北 + 全国」。与河北无关的（其他省份专属）**丢弃**。
            #   这条过滤用归档快照离线验过：四网现有数据一条都不会被它丢掉（只放过未知网）。
            #   真丢了就要吭声 —— 静默少一批条目在页面上完全看不出来。
            if code and not sc:
                dropped += 1
                continue
            # ★ 地市：**上游字段没有时**，允许从文案里认（仅移动 / 电信，见 CITY_TEXT）。
            #   这一段原先写在页面的 cityTags() 里，2026-09-24 搬到构建期 ——
            #   与 cat / chx / sc / st 同一条原则：归一在构建期做完写进行数据，
            #   页面只读不算。搬过来的实打实收益是**判据只剩一份**：
            #   原先页面与 audit_data 各有一份文本规则，靠 check_sync 比对字符串，
            #   而那段注释自己就写着「页面判据一升级，这里不跟着改，对账就从对得上
            #   滑成永远差一截；又因为平时没人跑，看上去只是噪音」。
            # ★★ 码判定与文案是**互补**而不是**互斥**（2026-09-24 修，此前是
            #   `if not cty`，即「有码就完全不看文案」）：
            #     · 地市**码**是权威的 —— 有码时不该再用文案去猜**别的 4 位码地市**，
            #       否则「唐山爱家光网回馈」会因说明里提到别处而被加上多余的地市；
            #     · 但 `CITY_EXTRA`（雄安新区 / 华北油田）**没有独立地市码**，只能靠文案 ——
            #       互斥写法让这两个档**永远是 0 条专属**（「沧州华油尊享礼包」的码是
            #       3170 沧州，只有名字里带「华油」），而 `text_cities()` 的注释自己
            #       早就写着「『沧州华油尊享礼包』同属沧州与华北油田」。
            #   ⇒ 无码：文案兜全量；有码：只用文案补 CITY_EXTRA。
            if code in CITY_TEXT:
                tb = text_cities(e)
                if not cty:
                    cty = tb
                else:
                    extra = [c for c in tb if c in CITY_EXTRA and c not in cty]
                    if extra:
                        cty = _uniq(list(cty) + extra)

            def s(k, n=400):
                v = e.get(k)
                return "" if v in (None, "None") else str(v).replace("\n", " ")[:n]
            chn = s("channel", 120)
            # ★ 流量「数值 + 单位」先归一（见 du_norm）：上游写法四网各不相同，
            #   不归一就会出现「100M 认不出单位 ⇒ 流量筛选把它漏掉」这类静默错。
            #   `g` 由**归一后**的 (d, du) 算，三者口径必然一致。
            d_n, du_n = du_norm(e.get("data"), e.get("dataUnit"))
            rec = {"n": s("name", 120), "t": s("tariffName", 80),
                   "f": fee_norm(s("fees", 20)), "d": d_n, "du": du_n,
                   "c": s("call", 20), "g": gb(d_n, du_n),
                   "ap": s("applicablePeople", 220), "ch": chn,
                   "o": s("onlineDay", 12), "e": s("offineDay", 12),
                   "ty": sub, "a1": attr, "r": s("reportNo", 30),
                   "x": s("otherContent", 500), "ex": s("extraFees", 200),
                   "vp": s("validPeriod", 200), "bw": s("brandwidth", 40),
                   "sc": sc,
                   # ★ 归一化结果在**构建期**算好写进行数据（而不是让页面查表）：
                   #   ① 页面只读不算，筛选/CSV/统计三处不会各算一遍导致口径漂移；
                   #   ② CI 断言能直接校验取值域（cat 必须落在 CAT_ORDER 内）；
                   #   ③ 探针复用同一份函数，结论与页面必然一致。
                   #   ★★ cat_src 而非 raw_l1 —— 联通停售桶要先按二级栏目还原，
                   #      见本函数开头那段「把停售套餐还原成真实分类」。
                   "cat": type_cat(cat_src), "chx": ch_norm(chn)}
            # ★ 办理门槛字段补全（2026-10-07 第二轮普查）：移动上游的 违约责任/
            #   办理限制/一次性费用/合约时长 4 个字段此前**没有一个**进过页面 ——
            #   实测 5280 行里 557 条实质违约责任条款（去重 193 种文案，含
            #   「优惠未履约期限乘以每月优惠金额 30 元」这类真金白银）、218 条
            #   duration 合约月数在 otherContent/validPeriod 里都查不到，
            #   是「办理必读高亮不够全」的最大漏源。归一成两个独立字段：
            #     rsp = responsibility 原文（详情「违约责任」行 + 办理必读扫描源；
            #           「无需承担违约责任」的否定句也保留 —— 详情看全文不误读）
            #     oth = others + otherFees + duration 补注（不单独展示全文，只作
            #           办理必读扫描源 —— others 大半是「各地市政策不同」这类
            #           boilerplate，铺全文是噪音；真门槛条款命中后以片段展示）
            #   🔴 为什么不并进 x：x 是 diff 感知字段，并入会让下一轮巡检把
            #   全量移动行标成「权益说明有变更」（一次性噪音 5000+ 行）。
            #   独立字段 diff 不感知（KEY_FIELDS 是 raw 快照字段，另一条链路），
            #   代价是变更检测暂感知不到这两字段的变化 —— 要感知时把它们加进
            #   KEY_FIELDS 即可，但要接受首轮全量 changed，另案评估。
            rsp_v = s("responsibility", 400)
            if rsp_v and rsp_v not in ("-", "无"):
                rec["rsp"] = rsp_v
            oth_parts = []
            for _k, _n in (("others", 240), ("otherFees", 120)):
                _v = s(_k, _n)
                if _v and _v not in ("-", "无") and not any(_v in p for p in oth_parts):
                    oth_parts.append(_v)
            # duration「24个月/要求在网24个月」是官方标的合约时长，且实测 218 条
            # 在文案里查不到 —— 补注一句让页面合约期正则能命中（避免构建期重复
            # 跑「文案是否已含合约期字样」的语义判断，只查时长子串是否已可见）。
            du_v = s("duration", 24)
            if du_v and du_v not in ("-", "无") and re.search(r"\d+\s*个月", du_v):
                if du_v not in rec["x"] and du_v not in rec["vp"]:
                    oth_parts.append("合约期时长：" + du_v)
            if oth_parts:
                rec["oth"] = "；".join(oth_parts)[:400]

            # ★ 板块：本网该字段真有两档才写。电信原是写死的 "2"（单档不落盘），
            #   2026-10-03 集团公示块接入后 _attrs={2,3}，电信也有了这一维。
            if sect_on and str(attr or "").strip() in ATTR_CN:
                rec["sect"] = ATTR_CN[str(attr).strip()]
            # ★ 溯源：**只在归一后与上游原文不同**时才写。
            #   一样的话是纯冗余（联通在售条目的 l1==cat_src、l2==sub，一条都不用写）；
            #   写入的三种情形：① 停售还原（l1=停售套餐、l2=原二级，对账不必回翻快照）；
            #   ② 细分改名/剥前缀（l2=上游原文，如「其他」→「其他加装」）；
            #   ③ 不含「细分与大类同名」——那不是还原（raw_l2==raw_l1），写 l2 只会
            #     让 2481 条标准资费白挂一个假溯源（🔴 判据 = raw_l2 != raw_l1）。
            if raw_l1 and raw_l1 != cat_src:
                rec["l1"] = raw_l1
            if raw_l2 and raw_l2 != sub and raw_l2 != raw_l1:
                rec["l2"] = raw_l2
            # ★ 归属（个人/政企）：只有移动的条目带 type1，其余三网连键都没有。
            #   与 cty 同策略 —— **有值才写**，免得页面拿到一堆空串还要判断。
            #   页面显隐该维度时看「本网有没有任一条目带 ow」，与地市判据一致。
            ow = OW_CN.get(s("type1", 4))
            if ow:
                rec["ow"] = ow
            # ★ 在售 / 已下架必须在写地市**之前**算出来 —— 地市与「不限地市」
            #   两档都只对在售条目成立（见下）。
            st = bool(code and state_of(code, e, g, base_day))
            # ★ 地市归属只有三种合法形态，**互斥且完备**（audit_data.check_city 会断言）：
            #     · `cty` 有值  = 该资费限这几个市（**中文名**，取值域 = CITY_ORDER ∪ CITY_EXTRA）
            #     · `pw=1`      = 不限地市（全省通用）—— 页面「仅全省通用」档读它
            #     · 两者皆无    = 归属不详（当前只出现在**已下架**条目上）
            #   空列表不落盘：免得页面拿到一堆 `cty: []` 误以为「这些条目属于第 0 个地市」。
            #   ★ 页面据此决定**要不要出地市这一层**（本网一条 cty 都没有 ⇒ 不出），
            #     不再依赖任何「本网不分城市」的声明 —— 那个声明错过一次，代价是
            #     整个维度被藏起来而无人察觉（见 WHERE_OF / net_payload 的注释）。
            # 🔴🔴 已下架条目的地市归属是**不可信**的，刻意不写：它的来源是各城
            #   「停售目录」的差异，而停售目录本质是各城各自的遗留清单 —— 同一条停售
            #   资费被哪些城市收录是**任意**的。实测 139 条「城市专属」里 18 条其实是
            #   9~11 城共有（含 6 条明摆着是「…-河北省版」的省版资费）；把它们算成
            #   「邢台专属」，用户按邢台筛时就会混进一批与邢台无关的条目。
            #   ⇒ 宁可让它们**没有任何地市归属**（只在「全部城市」下可见），
            #     也不要给一个看着正常、实则随机的标签。
            if not st:
                if cty:
                    rec["cty"] = cty
                elif code in CITY_NETS and str(attr or "").strip() != ATTR_GROUP_PUB:
                    # ★ 集团公示（电信 attr=3）不写 pw：目录本身就没有「地市」概念，
                    #   写 pw=1 会被「仅全省通用（不限地市）」档照单收进来 ——
                    #   用户在「河北 + 仅全省通用」下会看到 524 条集团公示混在
                    #   本省目录的全省资费里（2026-10-04 审查发现）。想看集团公示
                    #   ⇒ 板块下拉的「集团公示」档，那条路才是它的入口。
                    rec["pw"] = 1
            if st:
                rec["st"] = 1
            # ★ 行级变更标注：键必须与 index_rows() **逐字一致** ——
            #   取**未截断**的 name（name 缺失时退回 tariffName），重名追加 #2/#3。
            #   若图省事拿页面里那个截断到 120 的 n 去比，超长名字会静默对不上。
            if diff:
                nm = str(e.get("name") or e.get("tariffName") or "").strip()
                kb = "%s|%s|%s" % (g.get("type2"), attr, nm)
                seen[kb] = seen.get(kb, 0) + 1
                kb = kb if seen[kb] == 1 else "%s#%d" % (kb, seen[kb])
                if kb in diff["added"]:
                    rec["ca"] = 1
                if kb in diff["changed"]:
                    rec["ck"] = 1
            rows.append(rec)
    if dropped:
        log(f"!! {code}：{dropped} 条与河北/全国无关（其他省份专属）已按需求丢弃 —— "
            f"这批条目若正好落在本次 diff 里，变更标注会因条数对不上而整批撤销")
    # ★ 行主键去重序号（第 5 轮体检 S5，2026-10-06）：上游目录存在「同名同细分
    #   多版本」（新旧报告号并存，四网约 440 例）。页面键「网|细分|名称」不加序号
    #   会串行——收藏一颗星亮两行、详情/同价位定位取错行。对第 2+ 个重复行写 kd，
    #   页面 keyOf() 拼键时追加 #序号。首个出现的行不带 kd ⇒ 键逐字不变，
    #   存量收藏零影响（重复行此前本就无法被独立收藏）。
    _seen_pk = {}
    for _r in rows:
        _pk = (_r.get("ty") or "", _r.get("n") or _r.get("t") or "")
        _seen_pk[_pk] = _seen_pk.get(_pk, 0) + 1
        if _seen_pk[_pk] > 1:
            _r["kd"] = _seen_pk[_pk]
    return _mark_changes(rows, diff)


# 模板占位符 —— 只此一份。
# ★ 漏掉一个占位符的表现是：生成的页面里留着 `__XXX__`，JS 直接 ReferenceError，
#   整页白屏；而且**本地不一定复现**（要么走 build_html、要么走 render_only）。
#   原先是 build_html 与 render_only 各写一遍替换列表 —— 2026-09-22 加 __CAT_ORDER__
#   时就只改了 build_html，render_only 那侧静默漏掉。合并到一处，从结构上消除这种漏。
PLACEHOLDERS = ("__NETS__", "__N__", "__DATE__", "__CAT_ORDER__",
                "__OW_ORDER__", "__CITY_ORDER__", "__CITY_EXTRA__",
                "__HIST__", "__NOTICE__")


def js_json(obj):
    """把对象序列化成能**安全嵌进内联 <script> 块**的 JSON 字面量。

    🔴 为什么不能直接用 ``json.dumps``：它（尤其 ``ensure_ascii=False`` 时）
       **不转义** ``<`` ``>`` ``&``，而这些字符放在内联 ``<script>`` 里是
       HTML 解析器的雷 —— 只要数据里出现 ``</script``，HTML 解析器就在那里
       **提前闭合脚本块**，其后所有 JS 变成普通文本 ⇒ 整页白屏、交互全废，
       而页面看起来只是「打开是空的」，没人会想到是某条资费文案的锅。

       这不是假想风险：上游资费文案**实测带富文本 HTML** —— 移动的「权益说明」
       字段含真正的 ``<p>…</p>``（2026-09-23 实测 19 个 ``<``、11 个 ``</p>``）。
       文案由运营商运营人员填写，出现 ``</script`` 只是时间问题。

       ``\\u003c`` 在 JSON 里与 ``<`` **完全等价**，JS 解析后字符串一模一样，
       所以对页面功能零影响；体积只多几个字节（四网实测 +0.02%）。
    """
    return (json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
            .replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026"))


def fill_template(tpl, vals):
    """把模板占位符一次填掉。缺任何一个都**报错**，而不是留下 `__X__` 让页面坏掉。"""
    miss = [p for p in PLACEHOLDERS if p not in tpl]
    if miss:
        raise RuntimeError("模板缺少占位符：%s" % "、".join(miss))
    for p in PLACEHOLDERS:
        tpl = tpl.replace(p, str(vals.get(p, "")))
    return tpl


# ══ 页面数据紧凑编码（2026-10-06 页面体积治理）════════════════════
# 背景：页面 gz 1082KB 超过 900KB 预警线，且 95% 体积是注入的行数据 ——
#   15014 行每行都带全套键名（20+ × 4 字符 × 行数 ≈ 1.1MB 纯键名），
#   高重复字符串（ty 36 种 / cat 6 种 / ap 2492 种 / x 说明 46% 重复）反复写全称。
# 方案：**列式 + 逐列字典编码**（实测：数据块 gz 842KB → 731KB，原始 12.0MB → 6.4MB，
#   JSON.parse 量近减半；页面侧 rowsOf() 按网**懒解码**，首屏只解当前一网）。
# 契约：**进程内一切照旧**（net_payload 进出都是 rows 对象数组），编码只发生在
#   「注入页面」那一刻（encode_nets_for_page），解码只发生在「从页面读回」
#   （decode_nets_from_page，render_only 用）。这样编码对管线完全透明，
#   不会出现「半路某处拿到 cols 当 rows 用」的静默炸裂。
# 一致性：编码后**全量回解码比对**（encode 时做，不靠事后抽查）——
#   这个容器坏掉＝全站数据错，宁可构建失败也不能带病上线。

COL_DICT_RATIO = 0.85    # 字符串列重复率高于此才字典化（唯一列字典化反而费字节）


def _norm_row(r):
    """归一（编码前逐行做）：

    ① 丢掉值为 None 的键。页面 JS 的语义里「字段为空」一直是 ``d.k === undefined``
       （undefined 与 null 在所有判空写法下等价，但键集合少一个可以让列式回解码
       与原行**逐键相等**，一致性好验证）。
    ② 丢掉 ``n``（列表名）：n 与 t（套餐名）80% 逐字相同（15014 行实测 12086 行），
       相同时页面一律 ``n||t`` 回退显示（rowName/bwInfo/CSV 已同步适配）——
       重复的那份纯属白背。实测 NETS 段 gz 771KB → 688KB。检索/排序/收藏键全走
       rowName（同样 n||t），语义零变化；n 与 t **不同**的行照常保留 n。
    """
    out = {}
    for k, v in r.items():
        if v is None:
            continue
        if k == "n" and r.get("n") is not None and r.get("n") == r.get("t"):
            continue
        out[k] = v
    return out


def encode_rows_compact(rows):
    """rows（对象数组）→ 列式容器 ``{"k": [列名…], "c": {列: 值数组 | {"d": 索引, "D": 字典}}}``。

    先做 None→缺键 归一（见 _norm_row）；列名按首现顺序排列（与 rows_of 的
    构造顺序一致，diff 友好）；字符串列重复率超阈值才字典化（唯一列字典化
    反而费字节）。列数组里的 None 表示「该行没有这个键」，解码时跳过。
    """
    rows = [_norm_row(r) for r in rows]
    keys, seen = [], set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                keys.append(k)
    cols = {}
    for k in keys:
        vals = [r.get(k) for r in rows]
        strs = [v for v in vals if isinstance(v, str)]
        if strs and len(set(strs)) < COL_DICT_RATIO * len(strs):
            dic = sorted(set(strs))
            idx = {s: i for i, s in enumerate(dic)}
            cols[k] = {"d": [idx[v] if isinstance(v, str) else v for v in vals],
                       "D": dic}
        else:
            cols[k] = vals
    return {"k": keys, "c": cols}


def decode_rows_compact(container):
    """encode_rows_compact 的逆变换（Python 侧，供 render_only 读回页面时用）。

    值为 None 的格位跳过（不还原键）—— 与编码侧的 None→缺键 归一互为镜像，
    回解码结果与归一后的原行**逐键相等**（encode_nets_for_page 的比对依据）。
    """
    if not isinstance(container, dict) or "c" not in container:
        raise ValueError("列式容器缺 c 键（不是 encode_rows_compact 的产物？）")
    cols = container["c"]
    keys = container.get("k") or list(cols.keys())
    if not keys:
        return []
    # 行数取「首列的值数组长度」—— 首列若是字典列（{"d":…,"D":…}），
    # len(容器) 恒为 2，直接 len 会把整网行数错成 2（cbn 实测踩中）。
    first = cols.get(keys[0])
    n = len(first["d"]) if isinstance(first, dict) and "D" in first else len(first)
    vals = {}
    for k in keys:
        v = cols.get(k)
        if isinstance(v, dict) and "D" in v:
            vals[k] = [None if i is None else v["D"][i] for i in v["d"]]
        else:
            vals[k] = v
    out = []
    for i in range(n):
        out.append({k: vals[k][i] for k in keys if vals[k][i] is not None})
    return out


def encode_nets_for_page(nets):
    """四网容器 → 页面注入形态（每网 rows 换成列式 cols）。

    编码后逐网回解码**逐行比对**：不一致就抛异常终止构建 —— 带错数据的页面
    比没有页面更糟（用户会拿错数字去办业务）。
    """
    out = {}
    for code, p in nets.items():
        rows = p.get("rows") or []
        q = {k: v for k, v in p.items() if k != "rows"}
        q["cols"] = encode_rows_compact(rows)
        back = decode_rows_compact(q["cols"])
        want = [_norm_row(r) for r in rows]
        if len(back) != len(want) or any(
                back[i] != want[i] for i in range(len(want))):
            raise RuntimeError("列式编码回解码不一致（%s）—— 终止构建" % code)
        out[code] = q
    return out


def decode_nets_from_page(nets):
    """页面读回的四网容器 → 进程内形态（cols 解回 rows；纯 rows 的旧页面原样返回）。"""
    out = {}
    for code, p in (nets or {}).items():
        if isinstance(p, dict) and "rows" not in p and "cols" in p:
            q = dict(p)
            q["rows"] = decode_rows_compact(p["cols"])
            out[code] = q
        else:
            out[code] = p
    return out


HIST_SMP_KEEP = 30       # 页面注入：近 7 天轮次每轮最多保留的样本条数
HIST_SMP_KEEP_OLD = 12   # 7 天前的旧轮次样本上限（旧轮次很少回看，完整明细在 changes/*.md）
HIST_RECENT_DAYS = 7     # 「近期」窗口（相对 history 里最新一轮的日期）
                         # history.json 磁盘上仍是全量；页面只带裁剪后的样本 ——
                         # 裁断必须可见：模板按 {"k":"more","n":N} 渲染「…还有 N 条明细」。


def _dnum(s):
    """'2026-10-06' → 20261006（非法输入退 0，让坏日期落进「旧轮次」一侧）。"""
    try:
        return int(str(s).replace("-", ""))
    except (ValueError, TypeError):
        return 0


def hist_for_page(items):
    """history items → 页面注入形态：样本条数按轮次新旧分档截断。

    - 近 HIST_RECENT_DAYS 天的轮次：每轮最多 HIST_SMP_KEEP 条；
    - 更早的轮次：每轮最多 HIST_SMP_KEEP_OLD 条，且字段变更对照卡只留
      **变更字段**行（未变字段只是展示上下文，7 天前的「当时长什么样」
      去仓库 changes/<日期>.md 看全量）。
    裁掉的以 ``{"k":"more","n":N}`` 收尾，模板据此渲染「…还有 N 条明细」
    —— 截断必须**可见**，静默截断会让「样本里没有」被误读成「当时没有变化」。
    """
    items = list(items or [])
    maxd = max((_dnum(x.get("d")) for x in items), default=0)
    out = []
    for x in items:
        smp = x.get("smp") or []
        recent = maxd - _dnum(x.get("d")) <= HIST_RECENT_DAYS
        keep = HIST_SMP_KEEP if recent else HIST_SMP_KEEP_OLD
        kept = smp[:max(0, keep)]
        if not recent:
            kept = [_strip_unchanged(e) for e in kept]
        q = dict(x)
        q["smp"] = kept + ([{"k": "more", "n": len(smp) - len(kept)}]
                           if len(smp) > len(kept) else [])
        out.append(q)
    return out


def _strip_unchanged(e):
    """旧轮次的字段变更样本：对照卡只留**变更**行（r[3]==1）。

    全部行都未变更（理论不该有）时保留原样 —— 一行不留的对照卡没有信息量，
    还不如整卡退回 chip 形态（模板对空 rows 的 c 类样本就是这么降级的）。
    """
    if e.get("k") != "c" or not isinstance(e.get("rows"), list):
        return e
    chg = [r for r in e["rows"] if r[3]]
    if not chg or len(chg) == len(e["rows"]):
        return e
    q = dict(e)
    q["rows"] = chg
    return q


FEED_PATH = os.path.join(DOCS, "feed.xml")
FEED_KEEP = 60            # feed 只留最近 60 条「真变化」（约一个月的量）


def _rfc822(ts, d):
    """抓取时刻（``2026-10-04 06:05:00``）→ RSS pubDate 要求的 RFC822。
    ts 缺失/非法时退回日期当天零点 —— 宁可时间不精确，不能格式非法
    （非法 pubDate 会被一部分阅读器整条拒收）。"""
    import datetime as _dt
    from email.utils import format_datetime
    tz = _dt.timezone(_dt.timedelta(hours=8))     # fetchedAt 本就是北京时间
    try:
        t = _dt.datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").replace(tzinfo=tz)
    except Exception:
        try:
            t = _dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=tz)
        except Exception:
            t = _dt.datetime.now(tz)
    return format_datetime(t)


def write_feed():
    """生成 docs/feed.xml（RSS 2.0）—— 变更事件的机器友好出口（recheck-20261004 #10）。

    changes/*.md 在 GitHub 上可读、页面时间线给人看，但「监控」场景缺一个
    零成本订阅口：RSS 阅读器、n8n、十几行的小脚本都能直接吃。数据源**只**是
    history.json —— 它自带 (日期,网) 去重与 HIST_KEEP 上限，feed 跟着它走，
    不另立第二份事实（同一判据多份副本必然漂移，本仓库已吃过两次亏）。

    · 只收「真变化」（a/r/c 至少一个 >0）：基线/回弹/噪声/降级这类
      「没有业务变化」的记录进 feed 只会训练订阅者忽略整个频道。
    · pubDate 取抓取时刻 —— 它是数据自己的属性，重复构建字节稳定
      （feed 不带 lastBuildDate 也是同一个理由：内容不随构建时钟漂）。
    · link 指向 GitHub 上该网当天的变更报告（约定文件名 {tag}-日期.md）。
    """
    import xml.sax.saxutils as _xu
    items = [x for x in load_history().get("items") or []
             if (x.get("a") or 0) > 0 or (x.get("r") or 0) > 0
             or (x.get("c") or 0) > 0][-FEED_KEEP:][::-1]   # RSS 惯例：最新在前
    L = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<rss version="2.0"><channel>',
         '<title>河北四网资费每日监控 · 变更</title>',
         f'<link>https://github.com/{REPO}</link>',
         '<description>河北移动/联通/电信/广电资费目录每日巡检捕获的业务变更'
         '（新增 / 下线 / 字段变更）</description>',
         '<language>zh-CN</language>']
    for x in items:
        d = x.get("d") or ""
        tag = getattr(NETS.get(x.get("code")), "tag", "")
        fname = (tag + "-" if tag else "") + d + ".md"
        link = f"https://github.com/{REPO}/blob/main/cloud/tariff/changes/{fname}"
        parts = []
        if x.get("a"):
            parts.append(f"新增 {x['a']}")
        if x.get("r"):
            parts.append(f"下线 {x['r']}")
        if x.get("c"):
            parts.append(f"变更 {x['c']}")
        title = f"{d} {x.get('net') or x.get('code')}：{' · '.join(parts)}"
        desc = [title]
        for s in (x.get("smp") or [])[:5]:
            mark = {"a": "＋", "r": "－", "c": "±"}.get(s.get("k"), "·")
            if s.get("n"):
                desc.append(f"{mark} {s['n']}")
        # FD1（2026-10-04）：每类变化一个 <category>，阅读器/自动化脚本可按类过滤
        cats = "".join(f"<category>{_xu.escape(p.split(' ')[0])}</category>" for p in parts)
        L += ["<item>",
              f"<title>{_xu.escape(title)}</title>",
              f"<link>{_xu.escape(link)}</link>",
              cats,
              '<guid isPermaLink="false">'
              f"{_xu.escape(d + '-' + str(x.get('code') or ''))}</guid>",
              f"<pubDate>{_rfc822(str(x.get('ts') or '')[:19], d)}</pubDate>",
              f"<description>{_xu.escape(chr(10).join(desc))}</description>",
              "</item>"]
    L.append("</channel></rss>")
    txt = "\n".join(L) + "\n"
    if G:
        G.atomic_write_text(FEED_PATH, txt, newline="\n")
    else:
        with open(FEED_PATH, "w", encoding="utf-8") as f:
            f.write(txt)
    log(f"已更新订阅源（{os.path.relpath(FEED_PATH, BASE)}，{len(items)} 条真变化）")


def build_html(sources, notice="", diffs=None, archive=True):
    """重建查询页（多网）。

    ``sources``：``{网code: 数据源对象}`` —— 目前是 ``{"move": o, "unicom": o}``，
    缺哪家就哪家留空壳。
    ``diffs``：``{网code: {"added": set(键), "changed": set(键)}}``，按网各给一份；
    变更标注必须**按网分别算**（键里带分类号，两网的键空间不通用）。
    ``archive``：是否把结果 gzip 归档进 ``page/index.html.gz``（**入库的官方页面快照**）。
    🔴 本机预览路径（``rebuild_offline.py``）必须传 ``archive=False``：
       它的数据来自**本地采集缓存**（不入库），而归档进 git 的应是「与快照同源」的
       那一份。用本地缓存重建的页面盖掉官方归档，结果是归档与任何一份快照都对不上 ——
       既无法自证，也没人会注意到（2026-09-23 实测：跑一次本机重建，
       ``page/index.html.gz`` 就从 867218 字节变成 862474 字节，静默入库级别的改动）。
    """
    payloads, total = {}, 0
    for code, o in (sources or {}).items():
        if not o:
            continue
        d = (diffs or {}).get(code)
        rows = rows_of(o, d, code)
        sc_stat, cat_stat, st_n, cty_n, pw_n, unmapped = {}, {}, 0, 0, 0, {}
        for r in rows:
            sc_stat[r.get("sc")] = sc_stat.get(r.get("sc"), 0) + 1
            cat_stat[r.get("cat")] = cat_stat.get(r.get("cat"), 0) + 1
            st_n += 1 if r.get("st") else 0
            cty_n += 1 if r.get("cty") else 0
            pw_n += 1 if r.get("pw") else 0
            if r.get("cat") == "其他":
                unmapped[r.get("ty") or "(空)"] = unmapped.get(r.get("ty") or "(空)", 0) + 1
        # 地市那一格要**成对**打印（限定地市 / 不限地市）：
        # 只报「地市专属 N」看不出「剩下的都是不限地市」，也看不出某天采集侧
        # 把归属整批丢了（那一栏会从「专属 N」直接变成「无地市维度」，看着像正常的）。
        log("   %s：%d 条（%s%s%s）" % (
            code, len(rows),
            " · ".join("%s %d" % (SCOPE_CN.get(k, k or "?"), v)
                       for k, v in sorted(sc_stat.items())),
            (" · 地市专属 %d · 不限地市 %d" % (cty_n, pw_n)) if cty_n else " · 无地市维度",
            " · 已下架 %d" % st_n if st_n else ""))
        # 大类分布按 CAT_ORDER 输出（而不是 most_common）—— 顺序固定才便于逐日比对，
        # 也才能一眼看出「某网这次少了一整类」。
        log("     大类：" + " · ".join("%s %d" % (c, cat_stat[c])
                                     for c in CAT_ORDER if cat_stat.get(c)))
        if unmapped:
            log("     !! 有原始分类没归到大类（落进「其他」）：" + " · ".join(
                "%s×%d" % (k, v) for k, v in sorted(unmapped.items()))
                + " —— 请在 TYPE_CAT 里补映射（CI 会因此硬失败）")
        payloads[code] = {"rows": rows, "src": SRC_OF.get(code, ""),
                          # 🔴 2026-10-04 修：兜底不能用 today —— data_day() 自己的
                          #   docstring 写明「fallback 必须稳定，用 today 归档逐字节
                          #   去重就废了」。render_only() 早已改用 prev_day()，
                          #   这处是漏网之鱼（仅在移动外某网 fetchedAt 非法时触发）。
                          "base": data_day(o, prev_day()),
                          # 抓取时刻（分钟级）—— 页面「更新于」显示用，见 net_payload
                          "ts": str((o.get("fetchedAt") or ""))[:16]}
        total += len(rows)
    if not payloads:
        log("!! 没有任何一网的数据，放弃重建页面")
        return 0
    html = open(os.path.join(BASE, "template.html"), encoding="utf-8").read()
    # __DATE__ 只取「日期」部分，不取到秒（抓取时刻走 net_payload 的 ts，只进横栏）。
    # ★ 归档去重依赖「页面字节随数据走」：__DATE__/base 只随日期变，ts 随抓取变 ——
    #   纯模板重渲染两者都不动，去重照常生效（详见 archive_page 的注释）。
    # ★ __DATE__ 是「移动那网的基线」——页面顶部那行来源/基线/条数已改成
    #   由 JS 按当前网渲染（原来写死成移动的，切到联通会显示错的来源与条数），
    #   这个占位符只留作无 JS 时的后备文本，取移动的 base 最不容易误导。
    date = (payloads.get("move") or {}).get("base") or data_day(
        sources.get("move") or {}, prev_day())
    payload = js_json(encode_nets_for_page(net_payload(payloads)))
    out = fill_template(html, {
        "__NETS__": payload, "__N__": str(total), "__DATE__": date,
        # 大类顺序（不是数据）注入页面：页面按它生成下拉，顺序才和构建日志一致。
        # 在页面里另写一份常量就会漂移 —— 而漂移的表现是「下拉顺序和日志对不上」，
        # 不报错、只是慢慢让人不敢信。
        "__CAT_ORDER__": js_json(list(CAT_ORDER)),
        # 归属档位顺序（同 CAT_ORDER 的理由：顺序只此一份，页面不另写常量）。
        "__OW_ORDER__": js_json(list(OW_ORDER)),
        # 地市清单（2026-10-03 当晚恢复注入）：「地市」下拉按它建选项。
        # 白天曾随下拉一并撤掉；当晚用户要求恢复筛选（上游资费专区本就有
        # 城市选择器，只留徽标对「查查我市有什么」不友好）。常量本身从未动 ——
        # 它们始终是数据侧码 → 中文名的唯一出口（行数据 cty 由它算出），
        # CI 也照旧按 CITY_ALL 断言 cty 的取值域。
        "__CITY_ORDER__": js_json(list(CITY_ORDER)),
        "__CITY_EXTRA__": js_json(list(CITY_EXTRA)),
        # 变更历史（页面时间线）。走紧凑序列化 —— 它一年年涨，白空格也是体积。
        # smp 样本超 HIST_SMP_KEEP 截断（hist_for_page）：磁盘 history.json 全量，
        # 页面只带每轮前 30 条 + 「还有 N 条」标记 —— 全量明细在 changes/*.md。
        "__HIST__": js_json(hist_for_page(load_history().get("items") or [])),
        # notice=None → 用兜底文案；notice="" → 页面把提示条整个藏掉
        # （main() 在四网全部零变化时传空串 —— 「本次无变化」没有信息量）。
        "__NOTICE__": notice if notice is not None else "本次巡检未检测到变化"})
    # ★ 先写 .new 校验、再原子替换：这个文件坏掉＝全站白屏，而「写到一半」
    #   与「模板改坏」都不报错。校验不过就保留上一版可用页面（见 write_page）。
    ok, why = write_page(out)
    if not ok:
        log(f"!! 页面未替换（{why}）—— 上一版页面继续可用，请检查模板/占位符")
        return 0
    # 机器友好出口：history 在本轮 diff 时已落库，这里顺手把 RSS 刷新
    # （放 write_page 成功之后 —— 页面都出不来时没必要产出 feed）。
    write_feed()
    # gz 才是用户实际要下载的字节数：原始 2.5 MB 的页面 gz 后只有 245 KB，
    # 只看原始大小会高估一个数量级。多网接入后这个数字会翻几倍，所以要盯着。
    gz = len(gzip.compress(out.encode("utf-8"), 6))
    per = " · ".join("%s %d" % (c, len(p["rows"])) for c, p in payloads.items())
    log(f"已重建查询页（{total} 条：{per}，{os.path.getsize(HTML_DST)/1024:.0f} KB / "
        f"gz {gz/1024:.0f} KB）")
    if gz > GZ_WARN:
        log(f"!! 页面 gz 已 {gz/1024:.0f} KB，超过 {GZ_WARN/1024:.0f} KB 预警线。"
            f"再接入一家会继续翻 —— 该考虑按网拆分 / 按需加载，"
            f"而不是继续往单文件里塞")
    if archive:
        archive_page()
    else:
        log("（本机预览模式：不覆盖入库的官方归档 page/index.html.gz）")
    return total


def render_only():
    """不联网：拿现有 ``docs/index.html`` 里的数据，套当前 template.html 重渲染。

    为什么需要它：只改了模板（筛选项 / 样式 / 文案）时，**不该为了重建页面去跑抓取**。
    抓取会顺带写快照、写 ``changes/<今天>.md``、覆盖 ``state.json`` ——
    云端当天已经跑过一轮时，本地补跑会以「本地那份旧基准」生成一份不同的变更报告，
    把云端真实结果覆盖掉。所以重渲染必须走这条不碰数据的旁路。

    数据来源是页面里那段 ``const NETS={...}``（就是 build_html 注入的四网容器），
    用 ``JSONDecoder.raw_decode`` 取，比正则稳妥（字段正文里可能有 ``]`` 或 ``;``）。
    """
    if not os.path.exists(HTML_DST):
        log("!! 本地没有 docs/index.html —— 先跑一次完整巡检，或用 view_page.py 拉归档")
        return 3
    cur = open(HTML_DST, encoding="utf-8").read()
    m = re.search(r"const\s+NETS\s*=", cur)
    if m:
        try:
            nets, _ = json.JSONDecoder().raw_decode(cur[m.end():])
        except Exception as e:
            log(f"!! 解析现有页面数据失败：{type(e).__name__}: {e}")
            return 3
        if not isinstance(nets, dict) or not nets:
            log("!! 页面数据容器不是对象，放弃重建")
            return 3
        # 2026-10-06 页面数据改列式编码（encode_nets_for_page）：读回的第一步
        # 统一解回 rows 形态 —— 本函数后半段全部按 rows 契约工作，不该感知编码。
        nets = decode_nets_from_page(nets)
    else:
        # 兼容四网改造**之前**的页面（容器还是 `const DATA=[...]`）。
        # 没有这段就是死锁：想重建页面得先有 NETS，而 NETS 只有重建才写得出来。
        # 迁移过一次之后这个分支就再也不会进。
        mo = re.search(r"const\s+DATA\s*=", cur)
        if not mo:
            log("!! 现有页面里既没有 `const NETS=` 也没有 `const DATA=`，无法取数")
            return 3
        try:
            legacy, _ = json.JSONDecoder().raw_decode(cur[mo.end():])
        except Exception as e:
            log(f"!! 解析旧版页面数据失败：{type(e).__name__}: {e}")
            return 3
        if not isinstance(legacy, list) or not legacy:
            log("!! 旧版页面数据为空，放弃重建")
            return 3
        log(f"-- 检测到旧版页面（const DATA=，{len(legacy)} 条），本次按四网容器迁移")
        nets = net_payload({"move": {"rows": legacy}})
    mv = nets.get("move") or {}
    rows = mv.get("rows") or []
    if not isinstance(rows, list) or not rows:
        log("!! 页面数据为空，放弃重建（避免生成 0 条页面）")
        return 3
    # 重渲染要把**所有网**的条数都算上，否则顶部「共 N 条」会只报移动一家的。
    all_n = sum(len((nets.get(c) or {}).get("rows") or []) for c in SNAP_PREFIX)

    # 「来源」是**注册表里的元信息**，不是抓来的数据 ⇒ 重渲染时按 SRC_OF 刷新。
    # 不刷新的话，改一次来源文案还得跑一趟抓取才生效 —— 而抓取会顺带写快照、
    # 写当天的 changes/<今天>.md、覆盖 state.json，把云端真实结果顶掉。
    # 数据（rows）照旧一动不动，只动这一项元信息。
    for _c, _p in nets.items():
        if _c in SRC_OF and isinstance(_p, dict):
            _p["src"] = SRC_OF[_c]

    # 日期与通知必须沿用页面里的原值：基线日期是「数据基线」，
    # 重渲染不该让它漂移（漂移会让归档天天不等）。
    # 基线优先取 NETS["move"].base（唯一真相），退回页面正文的「数据基线 <日期>」。
    dm = re.search(r"数据基线 ([\d-]+)", cur)
    nm = re.search(r'id="notice">(.*?)</div>', cur, re.S)
    # 万一是空的/坏的，回退到**最新快照的日期**（稳定），而不是"今天"。
    date = data_day({"fetchedAt": mv.get("base") or (dm.group(1) if dm else "")}, prev_day())
    notice = nm.group(1).strip() if nm else ""
    mv["base"] = date     # 回填，保证静态 sub 与容器里的基线一致
    mv["rows"] = rows

    # 同 build_html：内联进 <script> 的 JSON 必须走 js_json 转义（防 </script 提前闭合）
    payload = js_json(encode_nets_for_page(nets))
    tpl = open(os.path.join(BASE, "template.html"), encoding="utf-8").read()
    try:
        out = fill_template(tpl, {
            "__NETS__": payload, "__N__": str(all_n), "__DATE__": date,
            "__CAT_ORDER__": js_json(list(CAT_ORDER)),
            "__OW_ORDER__": js_json(list(OW_ORDER)),
            "__CITY_ORDER__": js_json(list(CITY_ORDER)),
            "__CITY_EXTRA__": js_json(list(CITY_EXTRA)),
            "__HIST__": js_json(hist_for_page(load_history().get("items") or [])),
            "__NOTICE__": notice})
    except RuntimeError as e:
        log(f"!! {e}，中止（否则会留下未替换的标记把页面搞坏）")
        return 3
    ok, why = write_page(out)
    if not ok:
        log(f"!! 页面未替换（{why}）—— 上一版页面继续可用")
        return 3
    log(f"已按当前模板重渲染：共 {all_n} 条（移动 {len(rows)}）· 基线 {date or '?'} · "
        f"{os.path.getsize(HTML_DST)/1024:.0f} KB")
    archive_page()
    return 0


def prev_day(prefix="hebei_tariff_"):
    """最新快照文件对应的日期（YYYY-MM-DD）—— 用作基线日期的稳定回退值。"""
    fs = [os.path.basename(p) for p in snap_paths(prefix)]
    if not fs:
        return ""
    d = fs[-1][len(prefix):-len(".json.gz")]
    return f"{d[:4]}-{d[4:6]}-{d[6:]}" if re.fullmatch(r"\d{8}", d) else ""


def snap_paths(prefix="hebei_tariff_"):
    return sorted(os.path.join(SNAP, f) for f in os.listdir(SNAP)
                  if f.startswith(prefix) and f.endswith(".json.gz"))


def save_snapshot(data, day, prefix="hebei_tariff_"):
    """落一份快照。``day`` 必须是 **8 位紧凑日期**（``20260922``）。

    🔴 这里显式拒收带上横线的 ``2026-09-22`` —— 因为它**不会报错**，只会安静地
    写出一个 ``xxx_2026-09-22.json.gz``：文件名与 ``snap_paths()`` 的日期解析
    对不上，于是 ``load_prev`` / ``load_latest`` / ``prune`` 全都看不见它。
    症状是「快照看着存了，实际等于没存」，而次日巡检会拿更旧的基准比，
    一口气报出成百上千条假变更。这个坑本仓库真踩过（2026-09-22）。
    注意 ``data_day()`` 返的正是带横线的格式，两者**不能直接对接**，要 ``.replace("-", "")``。
    """
    if not re.fullmatch(r"\d{8}", str(day or "")):
        raise ValueError("快照日期必须是 8 位紧凑格式（如 20260922），收到 %r" % (day,))
    p = os.path.join(SNAP, f"{prefix}{day}.json.gz")
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # mtime=0 保证同样内容产生同样字节，避免无意义的二进制 diff
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=9, mtime=0) as f:
        f.write(raw)
    # ★ 原子写（.tmp → os.replace）：CI 有 timeout-minutes，进程随时可能被 kill。
    #   直接写目标文件被打断会留下**半个 gz**，下一轮解压失败或 diff 出一整批假变化。
    if G:
        G.atomic_write_bytes(p, buf.getvalue())
    else:
        with open(p, "wb") as f:
            f.write(buf.getvalue())
    log(f"快照已存 {os.path.basename(p)}（{os.path.getsize(p)/1024:.0f} KB，"
        f"原始 {len(raw)/1024/1024:.1f} MB）")
    return p


def prune_snapshots(prefix="hebei_tariff_"):
    fs = snap_paths(prefix)
    for p in fs[:-KEEP_SNAPSHOTS] if len(fs) > KEEP_SNAPSHOTS else []:
        os.remove(p)
        log(f"清理过期快照 {os.path.basename(p)}")


def load_prev(today, prefix="hebei_tariff_"):
    """选对比基准：优先「今天之前」最近的一份快照。

    ⚠️ 同一自然日重复运行时（手动补跑 / workflow_dispatch 验证），不会有「今天之前」
    的快照了，这时必须**退回用今天已存在的那份**当基准。

       否则第二次跑会被判成「首版基线」，然后 main() 里那条基线分支会把
       ``changes/<今天>.md`` 覆盖成一句「首版基线快照」——当天真实的新增/下线
       差异就这么静默丢了。（2026-09-20 实测踩到：当天补跑一次，3878→3879 的
       +1 变更被覆盖成基线文字。）

    真·首版（仓库里一份快照都没有）才返回 None。
    """
    name = f"{prefix}{today}.json.gz"
    fs = [p for p in snap_paths(prefix) if os.path.basename(p) < name]
    if not fs:
        fs = [p for p in snap_paths(prefix) if os.path.basename(p) == name]
    if not fs:
        return None, None
    p = fs[-1]
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return json.load(f), p


def load_latest(today, prefix="hebei_tariff_"):
    """渲染专用：取「不晚于今天」的最新一份快照（没有就退到全局最新）。

    🔴 刻意**不复用 load_prev()**：两者是不同语义。
      - load_prev  = 「上一版」，用于 diff —— 严格早于今天，当天有也算不上基准；
      - load_latest = 「最新版」，用于渲染 —— 当天采到的就要显示当天那份。
    用 load_prev 渲染，会出现「今天明明采到了、页面却还显示昨天」这种
    看着像没更新的假故障（NET_SNAP 的网尤其容易踩：它一天只可能被采一次）。
    """
    fs = [p for p in snap_paths(prefix)
          if os.path.basename(p)[len(prefix):-len(".json.gz")] <= today]
    if not fs:
        fs = snap_paths(prefix)
    if not fs:
        return None, None
    p = fs[-1]
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return json.load(f), p


def emit_summary(new_o, added, removed, changed, report_path, has_prev,
                 net="河北移动", summary=None):
    """把摘要写进 GITHUB_STEP_SUMMARY（Actions 页面上直接可读）。

    ``added`` / ``removed`` / ``changed`` 允许直接给**计数**（护栏路径下拿不到
    键列表，只有数字），也可以用列表 —— 列表时按其长度与内容展开样例。
    ``summary``：``diff_round()`` 的结果，给了就顺带把护栏数字与抑制原因写出来。
    """
    sp = os.environ.get("GITHUB_STEP_SUMMARY")
    if not sp:
        return
    idx = index_rows(new_o)

    def _n(x):
        return x if isinstance(x, int) else len(x or [])

    # 计数优先取 summary（护栏路径下拿到的就是数字）；
    # 样例只从**真键**里挑 —— 🔴 调用方为省事传过 `list(range(n))` 这种占位列表，
    # 若直接拿它当键去索引 idx 会 KeyError（占位元素是 int），而那会**在写摘要这一步
    # 把整轮巡检打断**：数据已经采完、报告也写了，却因为一行展示逻辑崩掉。
    na = int(summary["added"]) if summary and "added" in summary else _n(added)
    nr = int(summary["removed"]) if summary and "removed" in summary else _n(removed)
    nc = int(summary["changed"]) if summary and "changed" in summary else _n(changed)
    keys = [k for k in (added or []) if k in idx] if isinstance(added, (list, tuple)) else []
    L = [f"## {net}资费巡检 {new_o.get('fetchedAt')}", "",
         f"- 条目总数：**{len(idx)}**"]
    if not has_prev:
        L.append("- 本次为**首版基线**，后续运行才开始检测差异")
    elif summary and summary.get("note"):
        L.append(f"- ⚠️ 本轮**未记入任何变化**：{_NOTE_CN.get(summary['note'], summary['note'])}")
    else:
        L.append(f"- 新增 **{na}** · 下线 **{nr}** · 字段变更 **{nc}**")
        if not (na or nr or nc):
            L.append("- ✅ 未检测到变化")
        if summary:
            g = [f"补录 {summary.get('restored', 0)}",
                 f"假下架抑制 {summary.get('fake_removed', 0)}",
                 f"身份漂移合并 {summary.get('relocated', 0)}",
                 f"在售↔停售迁移 {summary.get('state_moved', 0)}"]
            if any(summary.get(k) for k in ("restored", "fake_removed",
                                            "relocated", "state_moved")):
                L.append("- 🛡 护栏：" + " · ".join(g))
        for k in keys[:15]:
            L.append(f"  - 🆕 **{idx[k]['_name'] or idx[k]['_tname']}** 〔{idx[k]['_ty']}〕{brief(idx[k])}")
        if na > len(keys[:15]):
            L.append(f"  - …另有 {na - len(keys[:15])} 条新增")
    L.append(f"\n完整报告：`{os.path.relpath(report_path, BASE)}`")
    with open(sp, "a", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


_NOTE_CN = {"degraded": "数据量异常，已冻结上一版（等下一轮复采）",
            "rebound": "检测到基线回弹，本轮不计入变化",
            "schema": "字段结构变更，仅重建基线、不通知",
            # 2026-10-04 noise_guard 接线：凡能产出的 note 这里必须有对照
            # （selftest 的覆盖断言盯着）。漏了 → 英文码原样印到中文界面。
            "noise": "疑似上游整批轮换子集（采样噪声），本轮不计变化",
            "baseline": "首版基线建立",
            "resync": "连续偏低后重同步基线",
            "collect-error": "本轮采集失败，沿用上一版快照",
            # 🔴 2026-09-26 补：漏了这一项时，下面的 .get(note, note) 兜底会
            #    把英文码 `snapshot-fallback` 原样印到中文界面上 —— 静默的英文泄漏。
            #    凡是系统**能产出**的 note，这里必须都有对照（有自测盯着，见
            #    selftest_pipeline.py 的「_NOTE_CN 覆盖全部 note 取值」）。
            "snapshot-fallback": "本轮未采到，沿用仓库快照渲染"}


def net_round(code, today, fallback=None):
    """跑一遍「非移动」的某一网：采集 → 降级自检 → 快照 → 变更检测 → 报告。

    与移动共用同一套机制（同 diff_round / index_rows / write_report），
    只有快照前缀与报告文件名不同 —— 各网必须各存各的，
    否则 load_prev 按文件名排序取「最近一份」时会把这一网的当成那一网的基准。

    ★ 任何一网失败**不致命**：抓不到就沿用上一版快照继续渲染，绝不因此让移动那网
      （或别的网）也出不了页面。返回 (数据, diff 或 None, summary 或 None)。

    ★ 收敛成一个函数而不是「联通一份、广电一份」：三网的流程逐字相同，
      只有模块名/显示名/文件名三处不同（都在 NET_RUN 里）。复制一份就等于
      把「降级保护」「沿用上次快照」「基线不覆盖」这些约束各写两遍 ——
      改一处漏一处时，症状是某网静默地不再保护数据。

    ``fallback``：采集失败 / 数据异常时用哪个「上一版」顶上，默认 ``load_prev``。
      电信（机会性采集）传 ``load_latest`` —— 本轮没采到时该用**最新那份**快照
      （可能就是今天早些时候采的），而不是「严格早于今天」的那份；
      否则明明仓库里有今天的数据，页面却退回昨天。
    """
    # 一网的「适配器 / 显示名 / 快照前缀 / 采不采停售 / 怎么采」现在都从注册表一次取齐
    # （原来要同时查 NET_RUN + SNAP_PREFIX + NET_STOPPED 三张表）。
    ns = NETS[code]
    cn, tag, prefix = ns.cn, ns.tag, ns.snap_prefix
    load = fallback or load_prev
    try:
        data = ns.fetch()
    except (Exception, SystemExit) as e:
        # SystemExit 也要接：ct_monitor.fetch_all() 在缺少 .ct_raw.json 时
        # 刻意用 SystemExit 抛出一段给**人看**的采集指引（本机直接跑时体验好）。
        # 只接 Exception 的话，一次「本轮没采到电信」会直接把整个巡检打断，
        # 连移动/联通/广电的页面都出不来 —— 正是这里最不该发生的事。
        log(f"!! {cn}采集异常，本轮沿用上次：{type(e).__name__}: {e}")
        d, _ = load(today, prefix)
        return d, None, _summary_skip(code, cn, d, "collect-error")
    old_o, prev_p = load_prev(today, prefix)
    if not data:
        log(f"!! {cn}采集失败，本轮沿用上次快照")
        return old_o, None, _summary_skip(code, cn, old_o, "collect-error")

    n = len(data.get("entries") or [])
    n_old = len((old_o or {}).get("entries") or [])
    if n == 0:
        log(f"!! {cn}抓到 0 条，本轮不写快照、沿用上次")
        rp, _ = _hold(code, cn, tag, data, old_o, prev_p, today,
                      "本轮抓到 0 条（采集整体失败）")
        return old_o, None, _summary_skip(code, cn, old_o, "degraded", report=rp)
    # ⑤ 降级状态机：单轮偏低先冻结，连续 N 轮才接受新数据
    act, why = _degrade(code, cn, n, n_old)
    if act == "hold":
        log(f"!! {cn}数据量异常 {n_old} -> {n}（<{DEGRADE_RATIO:.0%}），{why}，"
            f"本轮不写快照、沿用上次")
        rp, _ = _hold(code, cn, tag, data, old_o, prev_p, today,
                      f"本轮 {n} 条 < 上一版 {n_old} 条的 {DEGRADE_RATIO:.0%}，{why}")
        return old_o, None, _summary_skip(code, cn, old_o, "degraded", report=rp)
    if act == "accept":
        log(f"!! {cn}{why}（{n_old} -> {n}）—— 本轮按**重建基线**处理，不报变更")
    elif why:
        log(f"-- {cn}数据量已恢复正常（{n} 条）")

    save_snapshot(data, today, prefix)
    prune_snapshots(prefix)
    day = f"{today[:4]}-{today[4:6]}-{today[6:]}"
    rp = os.path.join(CHG, f"{tag}-{day}.md")

    if old_o is None or act == "accept":
        # 首版基线，或降级认账后的重同步：**只重建基线，不出变更报告**
        log(f"{cn}{'无历史快照' if old_o is None else '重同步'}，本次为首版基线（{n} 条）")
        if G:
            G.atomic_write_text(
                rp, f"# {cn}资费基线 · {data['fetchedAt']}\n\n"
                    f"- {'首版基线快照' if old_o is None else '数据量连续偏低后重同步'}"
                    f"，共 **{n}** 条\n- 来源：{SRC_TECH_OF[code]}\n", newline="\n")
        elif not os.path.exists(rp):
            with open(rp, "w", encoding="utf-8") as f:
                f.write(f"# {cn}资费基线 · {data['fetchedAt']}\n\n"
                        f"- 首版基线快照，共 **{n}** 条\n- 来源：{SRC_TECH_OF[code]}\n")
        hist_append({"ts": str(data.get("fetchedAt") or "")[:19], "d": day,
                     "code": code, "net": cn, "n": n, "a": 0, "r": 0, "c": 0,
                     "note": "baseline" if old_o is None else "resync", "smp": []})
        _clear_degrade(code)
        emit_summary(data, [], [], [], rp, False, net=cn)
        return data, None, {"code": code, "net": cn, "n": n, "added": 0, "removed": 0,
                            "changed": 0, "restored": 0, "fake_removed": 0,
                            "relocated": 0, "samples": [], "report": rp,
                            "note": "baseline" if old_o is None else "resync", "guard": None}

    sm = diff_round(code, cn, tag, data, old_o, prev_p, today, fname=f"{tag}-{day}.md")
    log(f"{cn}对比：新增 {sm['added']} 下线 {sm['removed']} 变更 {sm['changed']}"
        + (f" · 护栏：补录 {sm['restored']} / 假下架 {sm['fake_removed']} / "
           f"漂移 {sm['relocated']}" if (sm["restored"] or sm["fake_removed"]
                                         or sm["relocated"]) else ""))
    emit_summary(data, sm["_added_keys"], sm["_removed_keys"], sm["_changed_keys"],
                 sm["report"], True, net=cn, summary=sm)
    if sm["note"]:
        return data, None, sm
    return data, {"added": set(sm["_added_keys"]), "changed": set(sm["_changed_keys"])}, sm


def _clear_degrade(code):
    """某网重建基线后把它的降级计数清零（否则「上一轮的偏低」会一直挂账）。"""
    if not G:
        return
    st = G.read_json(DEGRADE_STATE, {}) or {}
    if code in st:
        st[code] = {"rounds": 0, "cleared": time.strftime("%Y-%m-%d %H:%M:%S")}
        G.write_json(DEGRADE_STATE, st)


def _summary_skip(code, cn, data, note, report=""):
    """本轮没有变更可报（采集失败 / 降级冻结）时的 summary 壳。"""
    return {"code": code, "net": cn,
            "n": len((data or {}).get("entries") or []),
            "added": 0, "removed": 0, "changed": 0, "restored": 0,
            "fake_removed": 0, "relocated": 0, "state_moved": 0, "samples": [],
            "report": report, "note": note, "guard": None}


def snap_net_ready(code, today):
    """兜底网（电信）本轮是否真拿到了采集产物 —— 决定走采集还是走快照。

    ★ 判据是**采集产物里记录的日期**，不是「文件在不在」：`.ct_raw.json` 不入库，
      但本机那份可能是上周采的，光看存在就走采集，会拿一份陈旧数据当今日快照入库
      （还会连带生成一份「电信无变化」的假报告）。用 mtime 更糟 ——
      CI 每次都是全新 checkout，mtime 恒为「现在」，等于恒真。
    """
    # 判据实现已收进 TelecomNet.ready()（连那段「为什么不能看文件在不在 / 不能看 mtime」
    # 的说明一起搬过去了）。这里**刻意保留成模块级函数**而不是让调用方直接调
    # NETS[code].ready()：selftest_pipeline.py 要打桩它，改成属性调用会让打桩点失效，
    # 于是自测「静默地测不到东西」—— 比报错更糟。
    return NETS[code].ready(today)


def other_nets(today):
    """把「移动之外」的每一网都跑一遍。

    返回 ``(sources, diffs, tails, summaries)``：
      ``sources`` = {网code: 数据源对象}（失败的那网是上一版快照，可能没有）
      ``diffs``   = {网code: {"added": set, "changed": set} 或 None}
      ``tails``   = [" · 联通新增 1、变更 2", " · 广电无变化"] 供页面顶部提示拼接
                    （零值段不写 —— G3，2026-10-04："变更 0" 是零信息量噪音）
      ``summaries`` = [diff_round 的 summary] —— 推送只在 main() 末尾汇总发一次，
                      所以各网的核验结果必须**带出来**（在网内部发就等于一网一条，
                      用户会在第一天把这个通道静音）。

    ★ 新增一网时**只需要动 NET_RUN**：main() 里不再逐个写 uni/cbn 变量。
      原来 main() 里两处（首版基线分支、常规分支）各写一遍联通的调用与提示拼接，
      接第三网就得改四处 —— 漏一处就是「某网采了但页面没提示 / 提示错字」。

    ★ 2026-09-22 追加 NET_SNAP（兜底名单，目前只有电信）：
      电信是「机会性采集」—— 云端有真实 Chrome 时采得到，采不到就退回仓库快照。
      两条路都从这里进，**不能只改 main()**：进页面有两条路（首版基线分支 &
      常规分支）都调本函数，只补一处，另一处就会静默少一网。
    """
    # 🔴 2026-09-26 修：这一行原本漏了 summaries，而函数体里三处 append 它 ——
    #    Python 按**全局名**去查，直接 NameError。它在 CI 上炸了第 8 步（整轮巡检中断、
    #    后面 12 步全 skip），而**本机所有自测都是绿的**：因为那些自测单独调 net_round /
    #    diff_round，**没有一个走到 other_nets 这个集成缝**。
    #    教训：函数级测试全过 ≠ 集成路径通。已加静态检查闸门（见 CI 的 ruff F821/F823）。
    sources, diffs, tails, summaries = {}, {}, [], []
    sh_of = {c: sh for c, sh, _ in NETS_META}
    for code in NET_LIVE:
        if code == "move":
            continue
        # 兜底网（电信）先确认「本轮真拿到了采集产物」再采 ——
        # 没有就跳过，交给下面的 NET_SNAP 用快照顶上。
        # 这一步必须在 net_round **之前**：ct_monitor 宁可抛 SystemExit 给一段
        # 人看的采集指引，也不肯静默返回空 —— 那对人是好事，对无人值守是打扰。
        if code in NET_SNAP and not snap_net_ready(code, today):
            continue
        fb = load_latest if code in NET_SNAP else None
        data, dd, sm = net_round(code, today, fallback=fb)
        sources[code] = data
        diffs[code] = dd
        if sm:
            summaries.append(sm)
        cn = sh_of.get(code, code)
        if dd:
            # G3（2026-10-04）：只写非零段 —— "新增 1 / 变更 0" 里的
            # "变更 0" 对读者零信息量；全零才写「无变化」。
            # 注意：quiet 判据（build_notice 的 endswith("无变化")）依赖
            # 「有变化的 tail 不以『无变化』结尾」，这里改格式后依然成立。
            parts = ([f"新增 {len(dd['added'])}"] if dd["added"] else []) \
                  + ([f"变更 {len(dd['changed'])}"] if dd["changed"] else [])
            tails.append(f" · {cn}{'、'.join(parts)}" if parts
                         else f" · {cn}无变化")
        elif sm and sm.get("note"):
            # 采集失败 / 降级冻结 / 回弹 / 结构变更 —— 这几种都**没有变更可报**，
            # 但绝不能显示成「无变化」：那是「看到了，没变」，
            # 而这些是「没看到」或「看到了但不敢信」，两者对读者的含义完全不同。
            tails.append(f" · {cn}{_NOTE_CN.get(sm['note'], sm['note'])}")
            if sm.get("note") == "degraded":
                print(f"::warning title={cn}本轮数据量异常::本轮 {sm['n']} 条，"
                      f"已冻结上一版数据、未记入变更", flush=True)

    # ── 快照兜底的网（电信本轮没采到时）────────────────────────────────
    # 提示语里必须带上**快照日期**：这一网在本轮里没有发生任何采集，
    # 只说「电信 884 条」会让人以为它今天也被抓过一次。日期是它唯一诚实的时效声明。
    for code in NET_SNAP:
        if sources.get(code):
            continue          # 本轮真采到了，不需要兜底
        cn = sh_of.get(code, code)
        o, p = load_latest(today, SNAP_PREFIX[code])
        if not o:
            log(f"!! {cn}没有可用快照（snapshots/{SNAP_PREFIX[code]}*.json.gz 缺失），"
                f"页面这一网将显示占位说明")
            continue
        sources[code] = o
        d8 = os.path.basename(p)[len(SNAP_PREFIX[code]):-len(".json.gz")]
        d10 = f"{d8[:4]}-{d8[4:6]}-{d8[6:]}" if re.fullmatch(r"\d{8}", d8) else d8
        tails.append(f" · {cn}沿用 {d10} 快照")
        summaries.append({"code": code, "net": cn, "n": len(o.get("entries") or []),
                          "added": 0, "removed": 0, "changed": 0, "restored": 0,
                          "fake_removed": 0, "relocated": 0, "state_moved": 0,
                          "samples": [], "report": "", "note": "snapshot-fallback",
                          "guard": None})
        log(f"{cn}由快照渲染：{os.path.basename(p)}（{len(o.get('entries') or [])} 条）")
    return sources, diffs, tails, summaries


def build_notice(move_sm, tails, special_notice=None):
    """页面顶部提示条的组装 —— main() 的集成缝提为纯函数（recheck-20261004 #8）。

    main() 全流程离线走不了（要采集、写快照、发推送），而 2026-09-26 的
    summaries NameError 与 2026-10-04 的 move_quiet 覆盖 bug 都出在这一段 ——
    「函数级自测全绿、main() 没人走」的病灶。提出来之后 selftest 直接喂桩
    数据就能断言两个方向：全网安静 ⇒ 空串（隐藏提示条）；特殊路径 ⇒ 警告
    永不隐藏。今后这段再改坏，离线单测当场炸，不用等 CI 跑真巡检才暴露。

    ``special_notice``：降级冻结 / 首版基线 / 重同步三条路径的提示语。
      非 None ⇒ 直接返回它拼 tails —— 这些警告本身就必须显示，绝不能被
      「全网安静就隐藏」的逻辑误伤（所以 quiet 只在常规分支算）。
    ``move_sm``：常规路径是 diff_round 的 summary；特殊路径调用方传 None。
    ``tails``：other_nets 拼好的其余各网提示（每条自带 " · " 前缀）。
    """
    if special_notice is not None or move_sm is None:
        return (special_notice or "") + "".join(tails)
    # 常规 diff 分支才算得出「quiet」：零新增/下线/变更，护栏也没摘过、补过任何东西。
    # 注意排除降级/回弹 —— 那几种 situation 走 _hold()，根本到不了这里。
    # 🔴 2026-10-04 复查修：quiet 的计算曾被挪到 if/else 之后用
    #    ``move_quiet = False`` 一刀切覆盖，「全网安静隐藏提示条」变成死逻辑，
    #    页面天天挂着「本次巡检未检测到任何变化 · 联通无变化 · …」。
    #    现在整段收进本函数：quiet 的算与用待在同一个作用域里，想覆盖也够不着。
    quiet = not (move_sm["added"] or move_sm["removed"] or move_sm["changed"]
                 or move_sm["relocated"] or move_sm["fake_removed"]
                 or move_sm["restored"])
    # 「变更了多少条」是一句话能说完的，「哪几条、变了什么」说不完 ——
    # 明细细在 changes/<日期>.md 里，别让用户自己翻仓库找当天那份。
    rel = repo_rel(move_sm["report"])
    tail = (f' · <a href="https://github.com/{REPO}/blob/main/{rel}"'
            f' target="_blank" rel="noopener">查看变更明细 →</a>')
    if quiet:
        notice = "本次巡检未检测到任何变化" + tail
    else:
        # G3（2026-10-04）：零值段不写 —— 非 quiet 时至少一段非零，
        # 把零段（如"字段变更 0 条"）一并印出来只是噪音。
        parts = ([f"新增 {move_sm['added']} 条"] if move_sm["added"] else []) \
              + ([f"下线 {move_sm['removed']} 条"] if move_sm["removed"] else []) \
              + ([f"字段变更 {move_sm['changed']} 条"] if move_sm["changed"] else [])
        notice = "本次巡检：" + " · ".join(parts) + tail
    if move_sm["relocated"] or move_sm["fake_removed"] or move_sm["restored"]:
        notice += (f" · 🛡 护栏另摘除 {move_sm['relocated'] + move_sm['fake_removed']}"
                   f" 条假变化、识别 {move_sm['restored']} 条补录")
    # 全网（含移动）都零变化 → 顶部提示条整个不显示：
    # 「本次无变化 · 联通无变化 · 广电无变化 · 电信无变化」对读者零信息量，
    # 天天挂着只会把真正需要看的提示（降级/沿用快照/真变化）淹没。
    # 判据是「tail 以『无变化』结尾」：降级/沿用快照那几种 tail 的文案不同，
    # 天然不会被误判成安静 —— 该显示的提示一条都不会被藏。
    if quiet and all(t.endswith("无变化") for t in tails):
        return ""
    return notice + "".join(tails)


def main():
    argv = sys.argv[1:]
    no_html = "--no-html" in argv
    no_notify = "--no-notify" in argv
    if "--render-only" in argv:
        return render_only()
    today = time.strftime("%Y%m%d")
    day10 = f"{today[:4]}-{today[4:6]}-{today[6:]}"

    data = fetch_all()
    if data is None:
        log("!! 抓取失败：分类列表拿不到")
        return 3
    n = sum(len(g["entries"]) for g in data["groups"])

    old_o, prev_p = load_prev(today)
    n_old = sum(len(g["entries"]) for g in (old_o or {}).get("groups") or [])

    if n == 0:
        log("!! 抓到 0 条，判为异常")
        return 2
    # ⑤ 降级状态机（与其余三网共用同一条判据与同一份计数）
    act, why = _degrade("move", "河北移动", n, n_old)
    if act == "hold":
        log(f"!! 数据量骤降 {n_old} -> {n}（<{DEGRADE_RATIO:.0%}），{why}，"
            f"本轮不写快照、不出报告，页面沿用上一版")
        _hold("move", "河北移动", "", data, old_o, prev_p, today,
              f"本轮 {n} 条 < 上一版 {n_old} 条的 {DEGRADE_RATIO:.0%}，{why}",
              fname=f"{day10}.md")
        # ⚠️ 这里**不再** return 2（老行为）。
        #   老代码在这一步直接失败退出 ⇒ 后面所有步骤（其余三网采集 / 页面重建 /
        #   部署）全部 skipped，页面**停在上一版且不留任何说明**。
        #   现在的行为是：页面照旧出（数据来自上一版快照），提示语里写明
        #   「本轮数据量异常，已冻结上一版」，并把 ::warning 打到 Actions 上。
        #   想恢复「硬失败」的老行为：环境变量 DEGRADE_STRICT=1。
        if os.getenv("DEGRADE_STRICT", "").strip() == "1":
            return 2
    elif act == "accept":
        log(f"!! {why}（{n_old} -> {n}）—— 本轮按**重建基线**处理，不报变更")
    elif why:
        log(f"-- 数据量已恢复正常（{n} 条）")

    frozen = (act == "hold")
    if not frozen:
        save_snapshot(data, today)
        prune_snapshots()

    # special_notice：三条特殊路径（降级冻结 / 首版基线 / 重同步）的提示语。
    # None = 常规 diff 分支，提示条由 build_notice() 组装（quiet 在函数内算）。
    # 🔴 2026-10-04 复查修：原先 move_quiet 的初始化放错位置被无条件覆盖，
    #    「全网安静隐藏提示条」永不触发。现在 quiet 的算与用全部收进
    #    build_notice()（recheck-20261004 #8），main() 里不再出现第二个副本。
    special_notice = None
    if old_o is None or act == "accept" or frozen:
        if frozen:
            move_sm = _summary_skip("move", "河北移动", old_o, "degraded")
            move_sm["report"] = os.path.join(CHG, f"{day10}.md")
            rp = move_sm["report"]
            special_notice = (f"⚠️ 本轮数据量异常（{n} 条 < 上一版 {n_old} 条），"
                              f"已冻结上一版数据、未记入变更")
            has_prev = True
        else:
            log(f"无历史快照，本次为首版基线（{n} 条）"
                if old_o is None else "数据量连续偏低后重同步，重建基线")
            rp = os.path.join(CHG, f"{day10}.md")
            move_sm = {"code": "move", "net": "河北移动",
                       "n": n if old_o is None else n_old, "added": 0, "removed": 0,
                       "changed": 0, "restored": 0, "fake_removed": 0, "relocated": 0,
                       "state_moved": 0, "samples": [], "report": rp,
                       "note": "baseline" if old_o is None else "resync", "guard": None}
            # 双保险：基线文字不覆盖已存在的当天报告。
            # load_prev() 已经保证「当天有快照就不会走到这里」，但万一快照被删/损坏，
            # 也不能把一份真实的变更报告换成一句「首版基线」。
            if os.path.exists(rp) and old_o is None:
                log(f"当天报告已存在，保留不覆盖：{os.path.relpath(rp, BASE)}")
            else:
                txt = (f"# 河北移动资费基线 · {data['fetchedAt']}\n\n"
                       f"- {'首版基线快照' if old_o is None else '数据量连续偏低后重同步'}"
                       f"，共 **{n}** 条\n"
                       f"- 来源：{SRC_TECH_OF['move']}\n")
                if G:
                    G.atomic_write_text(rp, txt, newline="\n")
                else:
                    with open(rp, "w", encoding="utf-8") as f:
                        f.write(txt)
            if old_o is None:
                hist_append({"ts": str(data.get("fetchedAt") or "")[:19], "d": day10,
                             "code": "move", "net": "河北移动",
                             "n": n, "a": 0, "r": 0, "c": 0, "note": "baseline",
                             "smp": []})
            special_notice = (f"首版基线建立（{n} 条），自次日起开始检测资费上下线变更"
                              if old_o is None
                              else f"数据量连续偏低后重同步基线（{n} 条）")
            has_prev = False
        _clear_degrade("move")
        emit_summary(data, [], [], [], rp, has_prev, summary=move_sm)
        move_diffs = None
    else:
        move_sm = diff_round("move", "河北移动", "", data, old_o, prev_p, today,
                             fname=f"{day10}.md")
        rp = move_sm["report"]
        log(f"对比 {os.path.basename(prev_p or '')}：新增 {move_sm['added']} "
            f"下线 {move_sm['removed']} 变更 {move_sm['changed']}"
            + (f" · 护栏：补录 {move_sm['restored']} / 假下架 {move_sm['fake_removed']} "
               f"/ 漂移 {move_sm['relocated']}"
               if (move_sm["restored"] or move_sm["fake_removed"]
                   or move_sm["relocated"]) else ""))
        _clear_degrade("move")
        if G:
            G.write_json(STATE_FILE, {"ts": data["fetchedAt"], "n": n, "prev_n": n_old,
                                      "added": move_sm["added"],
                                      "removed": move_sm["removed"],
                                      "changed": move_sm["changed"],
                                      "restored": move_sm["restored"],
                                      "fake_removed": move_sm["fake_removed"],
                                      "relocated": move_sm["relocated"],
                                      "note": move_sm["note"],
                                      "report": os.path.relpath(rp, BASE),
                                      "prev": os.path.basename(prev_p or "")})
        else:
            with open(STATE_FILE, "w", encoding="utf-8") as f:
                json.dump({"ts": data["fetchedAt"], "n": n, "prev_n": n_old,
                           "added": move_sm["added"], "removed": move_sm["removed"],
                           "changed": move_sm["changed"],
                           "report": os.path.relpath(rp, BASE),
                           "prev": os.path.basename(prev_p or "")},
                          f, ensure_ascii=False, indent=1)
        emit_summary(data, move_sm.get("_added_keys") or [],
                     move_sm.get("_removed_keys") or [],
                     move_sm.get("_changed_keys") or [],
                     rp, True, summary=move_sm)
        # move_sm 里的键集合是给页面标注用的（ca/ck）；护栏若判回弹则为空
        move_diffs = None if move_sm["note"] else {
            "added": set(move_sm["_added_keys"]),
            "changed": set(move_sm["_changed_keys"])}
        # 提示条组装已提纯为 build_notice()（见函数 docstring 与 recheck-20261004 #8）：
        # 常规分支只传 move_sm，quiet 与文案都在函数内算 —— main() 里不再有第二份副本。

    # ── 其余三网 + 页面 ───────────────────────────────────────────────
    # 页面每次都重建（本地那份必须是当天最新），但归档只在内容真变了时才写。
    # 「页面显示的时间停住」曾是个坑：所以页面主体显示的是「数据基线日期」；
    # 2026-10-03 起横栏「更新于」另显示各网快照的抓取时刻（net_payload 的 ts）——
    # 它是**数据自己的属性**（存在快照里），数据被冻结时跟着停在旧时刻，语义仍诚实。
    # 代价：同一天重跑（fetchedAt 变了、rows 没变）归档字节也会变、会多写一次 ——
    # 刻意接受（用户要求看到更新时刻），约 1 MB/次，频率很低。
    # 想知道巡检有没有在跑，看 state.json（view_page 会读）。
    # ★ 提示条组装（含 quiet 判定）已全部收进 build_notice()：三条特殊路径的
    #   special_notice 直接拼接（警告永不隐藏），quiet 只在常规分支内算 ——
    #   「算与用」待在同一个作用域里，覆盖类 bug 无处安放（recheck-20261004 #8）。
    summaries = [move_sm]
    if not no_html:
        extra, xdiff, tails, xsum = other_nets(today)
        summaries += xsum
        # 提示条整条的组装与「全网安静⇒隐藏」判定都在 build_notice() 里
        # （纯函数、selftest 喂桩可测）。这里只负责喂数据。
        notice = build_notice(move_sm, tails, special_notice)
        diffs = {"move": move_diffs} if move_diffs else {}
        diffs.update(xdiff)
        # 「结构变更 ⇒ 重建基线不通知」的收尾：结构变了但页面照常重建
        # （页面读的是数据，不是 diff），只是不把它当成一次「变化」推出去。
        build_html(dict({"move": data}, **extra), notice, diffs)
    else:
        # --no-html 也要跑其余三网：不然「另三网的快照与报告」会缺失，
        # 而 --no-html 的语义只是「不重建页面」，不是「只跑移动」。
        _, _, _, xsum = other_nets(today)
        summaries += xsum

    log(f"变更报告 {os.path.relpath(rp, BASE)}")

    # ── 推送：一次巡检只发一条 ────────────────────────────────────────
    # 放在最末尾：前面所有步骤都不该因为推送而改变结果（推送失败也不影响巡检）。
    if not no_notify and NOTIFY:
        try:
            NOTIFY.notify_change(day10, summaries,
                                 extra_notes=[n for n in _verify_notes(summaries)],
                                 repo=REPO)
        except Exception as e:
            log(f"!! 推送异常（不影响巡检结果）：{type(e).__name__}: {e}")
    elif _N_ERR:
        log(f"-- 推送模块不可用：{_N_ERR}")
    return 0


def _verify_notes(summaries):
    """给推送正文补几句「为什么数字是这样」的说明。"""
    out = []
    for s in summaries or []:
        if s.get("note") and s["note"] not in ("baseline", "snapshot-fallback"):
            out.append(f"{s['net']}：{_NOTE_CN.get(s['note'], s['note'])}")
    return out


if __name__ == "__main__":
    sys.exit(main())
